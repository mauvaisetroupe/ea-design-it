"use strict";
(self["webpackChunkea_design_it"] = self["webpackChunkea_design_it"] || []).push([["src_main_webapp_app_entities_data-flow-item_data-flow-item-update_vue"],{

/***/ "./node_modules/ts-loader/index.js??clonedRuleSet-1[0].rules[0].use[0]!./src/main/webapp/app/entities/data-flow-item/data-flow-item-update.component.ts?vue&type=script&lang=ts&":
/*!***************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/ts-loader/index.js??clonedRuleSet-1[0].rules[0].use[0]!./src/main/webapp/app/entities/data-flow-item/data-flow-item-update.component.ts?vue&type=script&lang=ts& ***!
  \***************************************************************************************************************************************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony import */ var vue_property_decorator__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! vue-property-decorator */ "./node_modules/vue-property-decorator/lib/index.js");
/* harmony import */ var vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! vuelidate/lib/validators */ "./node_modules/vuelidate/lib/validators/index.js");
/* harmony import */ var _shared_model_data_flow_item_model__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @/shared/model/data-flow-item.model */ "./src/main/webapp/app/shared/model/data-flow-item.model.ts");
var __extends = (undefined && undefined.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        if (typeof b !== "function" && b !== null)
            throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};



var validations = {
    dataFlowItem: {
        resourceName: {
            required: vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_2__.required,
        },
        resourceType: {},
        description: {
            maxLength: (0,vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_2__.maxLength)(1000),
        },
        contractURL: {
            maxLength: (0,vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_2__.maxLength)(500),
        },
        documentationURL: {
            maxLength: (0,vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_2__.maxLength)(500),
        },
        startDate: {},
        endDate: {},
    },
};
var DataFlowItemUpdate = /** @class */ (function (_super) {
    __extends(DataFlowItemUpdate, _super);
    function DataFlowItemUpdate() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.dataFlowItem = new _shared_model_data_flow_item_model__WEBPACK_IMPORTED_MODULE_1__.DataFlowItem();
        _this.dataFlows = [];
        _this.isSaving = false;
        _this.currentLanguage = '';
        return _this;
    }
    DataFlowItemUpdate.prototype.beforeRouteEnter = function (to, from, next) {
        next(function (vm) {
            if (to.params.dataFlowItemId) {
                vm.retrieveDataFlowItem(to.params.dataFlowItemId);
            }
            vm.initRelationships();
        });
    };
    DataFlowItemUpdate.prototype.created = function () {
        var _this = this;
        this.currentLanguage = this.$store.getters.currentLanguage;
        this.$store.watch(function () { return _this.$store.getters.currentLanguage; }, function () {
            _this.currentLanguage = _this.$store.getters.currentLanguage;
        });
    };
    DataFlowItemUpdate.prototype.save = function () {
        var _this = this;
        this.isSaving = true;
        if (this.dataFlowItem.id) {
            this.dataFlowItemService()
                .update(this.dataFlowItem)
                .then(function (param) {
                _this.isSaving = false;
                _this.$router.go(-1);
                var message = 'A DataFlowItem is updated with identifier ' + param.id;
                return _this.$root.$bvToast.toast(message.toString(), {
                    toaster: 'b-toaster-top-center',
                    title: 'Info',
                    variant: 'info',
                    solid: true,
                    autoHideDelay: 5000,
                });
            })
                .catch(function (error) {
                _this.isSaving = false;
                _this.alertService().showHttpError(_this, error.response);
            });
        }
        else {
            this.dataFlowItemService()
                .create(this.dataFlowItem)
                .then(function (param) {
                _this.isSaving = false;
                _this.$router.go(-1);
                var message = 'A DataFlowItem is created with identifier ' + param.id;
                _this.$root.$bvToast.toast(message.toString(), {
                    toaster: 'b-toaster-top-center',
                    title: 'Success',
                    variant: 'success',
                    solid: true,
                    autoHideDelay: 5000,
                });
            })
                .catch(function (error) {
                _this.isSaving = false;
                _this.alertService().showHttpError(_this, error.response);
            });
        }
    };
    DataFlowItemUpdate.prototype.retrieveDataFlowItem = function (dataFlowItemId) {
        var _this = this;
        this.dataFlowItemService()
            .find(dataFlowItemId)
            .then(function (res) {
            _this.dataFlowItem = res;
        })
            .catch(function (error) {
            _this.alertService().showHttpError(_this, error.response);
        });
    };
    DataFlowItemUpdate.prototype.previousState = function () {
        this.$router.go(-1);
    };
    DataFlowItemUpdate.prototype.initRelationships = function () {
        var _this = this;
        this.dataFlowService()
            .retrieve()
            .then(function (res) {
            _this.dataFlows = res.data;
        });
    };
    __decorate([
        (0,vue_property_decorator__WEBPACK_IMPORTED_MODULE_0__.Inject)('dataFlowItemService'),
        __metadata("design:type", Function)
    ], DataFlowItemUpdate.prototype, "dataFlowItemService", void 0);
    __decorate([
        (0,vue_property_decorator__WEBPACK_IMPORTED_MODULE_0__.Inject)('alertService'),
        __metadata("design:type", Function)
    ], DataFlowItemUpdate.prototype, "alertService", void 0);
    __decorate([
        (0,vue_property_decorator__WEBPACK_IMPORTED_MODULE_0__.Inject)('dataFlowService'),
        __metadata("design:type", Function)
    ], DataFlowItemUpdate.prototype, "dataFlowService", void 0);
    DataFlowItemUpdate = __decorate([
        (0,vue_property_decorator__WEBPACK_IMPORTED_MODULE_0__.Component)({
            validations: validations,
        })
    ], DataFlowItemUpdate);
    return DataFlowItemUpdate;
}(vue_property_decorator__WEBPACK_IMPORTED_MODULE_0__.Vue));
/* harmony default export */ __webpack_exports__["default"] = (DataFlowItemUpdate);


/***/ }),

/***/ "./src/main/webapp/app/shared/model/data-flow-item.model.ts":
/*!******************************************************************!*\
  !*** ./src/main/webapp/app/shared/model/data-flow-item.model.ts ***!
  \******************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "DataFlowItem": function() { return /* binding */ DataFlowItem; }
/* harmony export */ });
var DataFlowItem = /** @class */ (function () {
    function DataFlowItem(id, resourceName, resourceType, description, contractURL, documentationURL, startDate, endDate, dataFlow) {
        this.id = id;
        this.resourceName = resourceName;
        this.resourceType = resourceType;
        this.description = description;
        this.contractURL = contractURL;
        this.documentationURL = documentationURL;
        this.startDate = startDate;
        this.endDate = endDate;
        this.dataFlow = dataFlow;
    }
    return DataFlowItem;
}());



/***/ }),

/***/ "./src/main/webapp/app/entities/data-flow-item/data-flow-item-update.vue":
/*!*******************************************************************************!*\
  !*** ./src/main/webapp/app/entities/data-flow-item/data-flow-item-update.vue ***!
  \*******************************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _data_flow_item_update_vue_vue_type_template_id_1bffe39c___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./data-flow-item-update.vue?vue&type=template&id=1bffe39c& */ "./src/main/webapp/app/entities/data-flow-item/data-flow-item-update.vue?vue&type=template&id=1bffe39c&");
/* harmony import */ var _data_flow_item_update_component_ts_vue_type_script_lang_ts___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./data-flow-item-update.component.ts?vue&type=script&lang=ts& */ "./src/main/webapp/app/entities/data-flow-item/data-flow-item-update.component.ts?vue&type=script&lang=ts&");
/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! !../../../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */
;
var component = (0,_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _data_flow_item_update_component_ts_vue_type_script_lang_ts___WEBPACK_IMPORTED_MODULE_1__["default"],
  _data_flow_item_update_vue_vue_type_template_id_1bffe39c___WEBPACK_IMPORTED_MODULE_0__.render,
  _data_flow_item_update_vue_vue_type_template_id_1bffe39c___WEBPACK_IMPORTED_MODULE_0__.staticRenderFns,
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "src/main/webapp/app/entities/data-flow-item/data-flow-item-update.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./src/main/webapp/app/entities/data-flow-item/data-flow-item-update.component.ts?vue&type=script&lang=ts&":
/*!*****************************************************************************************************************!*\
  !*** ./src/main/webapp/app/entities/data-flow-item/data-flow-item-update.component.ts?vue&type=script&lang=ts& ***!
  \*****************************************************************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_ts_loader_index_js_clonedRuleSet_1_0_rules_0_use_0_data_flow_item_update_component_ts_vue_type_script_lang_ts___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../../node_modules/ts-loader/index.js??clonedRuleSet-1[0].rules[0].use[0]!./data-flow-item-update.component.ts?vue&type=script&lang=ts& */ "./node_modules/ts-loader/index.js??clonedRuleSet-1[0].rules[0].use[0]!./src/main/webapp/app/entities/data-flow-item/data-flow-item-update.component.ts?vue&type=script&lang=ts&");
 /* harmony default export */ __webpack_exports__["default"] = (_node_modules_ts_loader_index_js_clonedRuleSet_1_0_rules_0_use_0_data_flow_item_update_component_ts_vue_type_script_lang_ts___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./src/main/webapp/app/entities/data-flow-item/data-flow-item-update.vue?vue&type=template&id=1bffe39c&":
/*!**************************************************************************************************************!*\
  !*** ./src/main/webapp/app/entities/data-flow-item/data-flow-item-update.vue?vue&type=template&id=1bffe39c& ***!
  \**************************************************************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": function() { return /* reexport safe */ _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_data_flow_item_update_vue_vue_type_template_id_1bffe39c___WEBPACK_IMPORTED_MODULE_0__.render; },
/* harmony export */   "staticRenderFns": function() { return /* reexport safe */ _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_data_flow_item_update_vue_vue_type_template_id_1bffe39c___WEBPACK_IMPORTED_MODULE_0__.staticRenderFns; }
/* harmony export */ });
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_data_flow_item_update_vue_vue_type_template_id_1bffe39c___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./data-flow-item-update.vue?vue&type=template&id=1bffe39c& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./src/main/webapp/app/entities/data-flow-item/data-flow-item-update.vue?vue&type=template&id=1bffe39c&");


/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./src/main/webapp/app/entities/data-flow-item/data-flow-item-update.vue?vue&type=template&id=1bffe39c&":
/*!*****************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./src/main/webapp/app/entities/data-flow-item/data-flow-item-update.vue?vue&type=template&id=1bffe39c& ***!
  \*****************************************************************************************************************************************************************************************************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": function() { return /* binding */ render; },
/* harmony export */   "staticRenderFns": function() { return /* binding */ staticRenderFns; }
/* harmony export */ });
var render = function () {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c("div", { staticClass: "row justify-content-center" }, [
    _c("div", { staticClass: "col-8" }, [
      _c(
        "form",
        {
          attrs: { name: "editForm", role: "form", novalidate: "" },
          on: {
            submit: function ($event) {
              $event.preventDefault()
              return _vm.save()
            },
          },
        },
        [
          _c(
            "h2",
            {
              attrs: {
                id: "eaDesignItApp.dataFlowItem.home.createOrEditLabel",
                "data-cy": "DataFlowItemCreateUpdateHeading",
              },
            },
            [
              _c("font-awesome-icon", {
                staticStyle: { color: "Tomato", "font-size": "0.7em" },
                attrs: { icon: "clone" },
              }),
              _vm._v(" Create or edit a DataFlowItem\n      "),
            ],
            1
          ),
          _vm._v(" "),
          _c("div", [
            _vm.dataFlowItem.id
              ? _c("div", { staticClass: "form-group" }, [
                  _c("label", { attrs: { for: "id" } }, [_vm._v("ID")]),
                  _vm._v(" "),
                  _c("input", {
                    directives: [
                      {
                        name: "model",
                        rawName: "v-model",
                        value: _vm.dataFlowItem.id,
                        expression: "dataFlowItem.id",
                      },
                    ],
                    staticClass: "form-control",
                    attrs: { type: "text", id: "id", name: "id", readonly: "" },
                    domProps: { value: _vm.dataFlowItem.id },
                    on: {
                      input: function ($event) {
                        if ($event.target.composing) {
                          return
                        }
                        _vm.$set(_vm.dataFlowItem, "id", $event.target.value)
                      },
                    },
                  }),
                ])
              : _vm._e(),
            _vm._v(" "),
            _c("div", { staticClass: "form-group" }, [
              _c(
                "label",
                {
                  staticClass: "form-control-label",
                  attrs: { for: "data-flow-item-resourceName" },
                },
                [_vm._v("Resource Name")]
              ),
              _vm._v(" "),
              _c("input", {
                directives: [
                  {
                    name: "model",
                    rawName: "v-model",
                    value: _vm.$v.dataFlowItem.resourceName.$model,
                    expression: "$v.dataFlowItem.resourceName.$model",
                  },
                ],
                staticClass: "form-control",
                class: {
                  valid: !_vm.$v.dataFlowItem.resourceName.$invalid,
                  invalid: _vm.$v.dataFlowItem.resourceName.$invalid,
                },
                attrs: {
                  type: "text",
                  name: "resourceName",
                  id: "data-flow-item-resourceName",
                  "data-cy": "resourceName",
                  required: "",
                },
                domProps: { value: _vm.$v.dataFlowItem.resourceName.$model },
                on: {
                  input: function ($event) {
                    if ($event.target.composing) {
                      return
                    }
                    _vm.$set(
                      _vm.$v.dataFlowItem.resourceName,
                      "$model",
                      $event.target.value
                    )
                  },
                },
              }),
              _vm._v(" "),
              _vm.$v.dataFlowItem.resourceName.$anyDirty &&
              _vm.$v.dataFlowItem.resourceName.$invalid
                ? _c("div", [
                    !_vm.$v.dataFlowItem.resourceName.required
                      ? _c("small", { staticClass: "form-text text-danger" }, [
                          _vm._v(" This field is required. "),
                        ])
                      : _vm._e(),
                  ])
                : _vm._e(),
            ]),
            _vm._v(" "),
            _c("div", { staticClass: "form-group" }, [
              _c(
                "label",
                {
                  staticClass: "form-control-label",
                  attrs: { for: "data-flow-item-resourceType" },
                },
                [_vm._v("Resource Type")]
              ),
              _vm._v(" "),
              _c("input", {
                directives: [
                  {
                    name: "model",
                    rawName: "v-model",
                    value: _vm.$v.dataFlowItem.resourceType.$model,
                    expression: "$v.dataFlowItem.resourceType.$model",
                  },
                ],
                staticClass: "form-control",
                class: {
                  valid: !_vm.$v.dataFlowItem.resourceType.$invalid,
                  invalid: _vm.$v.dataFlowItem.resourceType.$invalid,
                },
                attrs: {
                  type: "text",
                  name: "resourceType",
                  id: "data-flow-item-resourceType",
                  "data-cy": "resourceType",
                },
                domProps: { value: _vm.$v.dataFlowItem.resourceType.$model },
                on: {
                  input: function ($event) {
                    if ($event.target.composing) {
                      return
                    }
                    _vm.$set(
                      _vm.$v.dataFlowItem.resourceType,
                      "$model",
                      $event.target.value
                    )
                  },
                },
              }),
            ]),
            _vm._v(" "),
            _c("div", { staticClass: "form-group" }, [
              _c(
                "label",
                {
                  staticClass: "form-control-label",
                  attrs: { for: "data-flow-item-description" },
                },
                [_vm._v("Description")]
              ),
              _vm._v(" "),
              _c("input", {
                directives: [
                  {
                    name: "model",
                    rawName: "v-model",
                    value: _vm.$v.dataFlowItem.description.$model,
                    expression: "$v.dataFlowItem.description.$model",
                  },
                ],
                staticClass: "form-control",
                class: {
                  valid: !_vm.$v.dataFlowItem.description.$invalid,
                  invalid: _vm.$v.dataFlowItem.description.$invalid,
                },
                attrs: {
                  type: "text",
                  name: "description",
                  id: "data-flow-item-description",
                  "data-cy": "description",
                },
                domProps: { value: _vm.$v.dataFlowItem.description.$model },
                on: {
                  input: function ($event) {
                    if ($event.target.composing) {
                      return
                    }
                    _vm.$set(
                      _vm.$v.dataFlowItem.description,
                      "$model",
                      $event.target.value
                    )
                  },
                },
              }),
              _vm._v(" "),
              _vm.$v.dataFlowItem.description.$anyDirty &&
              _vm.$v.dataFlowItem.description.$invalid
                ? _c("div", [
                    !_vm.$v.dataFlowItem.description.maxLength
                      ? _c("small", { staticClass: "form-text text-danger" }, [
                          _vm._v(
                            "\n              This field cannot be longer than 1000 characters.\n            "
                          ),
                        ])
                      : _vm._e(),
                  ])
                : _vm._e(),
            ]),
            _vm._v(" "),
            _c("div", { staticClass: "form-group" }, [
              _c(
                "label",
                {
                  staticClass: "form-control-label",
                  attrs: { for: "data-flow-item-contractURL" },
                },
                [_vm._v("Contract URL")]
              ),
              _vm._v(" "),
              _c("input", {
                directives: [
                  {
                    name: "model",
                    rawName: "v-model",
                    value: _vm.$v.dataFlowItem.contractURL.$model,
                    expression: "$v.dataFlowItem.contractURL.$model",
                  },
                ],
                staticClass: "form-control",
                class: {
                  valid: !_vm.$v.dataFlowItem.contractURL.$invalid,
                  invalid: _vm.$v.dataFlowItem.contractURL.$invalid,
                },
                attrs: {
                  type: "text",
                  name: "contractURL",
                  id: "data-flow-item-contractURL",
                  "data-cy": "contractURL",
                },
                domProps: { value: _vm.$v.dataFlowItem.contractURL.$model },
                on: {
                  input: function ($event) {
                    if ($event.target.composing) {
                      return
                    }
                    _vm.$set(
                      _vm.$v.dataFlowItem.contractURL,
                      "$model",
                      $event.target.value
                    )
                  },
                },
              }),
              _vm._v(" "),
              _vm.$v.dataFlowItem.contractURL.$anyDirty &&
              _vm.$v.dataFlowItem.contractURL.$invalid
                ? _c("div", [
                    !_vm.$v.dataFlowItem.contractURL.maxLength
                      ? _c("small", { staticClass: "form-text text-danger" }, [
                          _vm._v(
                            "\n              This field cannot be longer than 500 characters.\n            "
                          ),
                        ])
                      : _vm._e(),
                  ])
                : _vm._e(),
            ]),
            _vm._v(" "),
            _c("div", { staticClass: "form-group" }, [
              _c(
                "label",
                {
                  staticClass: "form-control-label",
                  attrs: { for: "data-flow-item-documentationURL" },
                },
                [_vm._v("Documentation URL")]
              ),
              _vm._v(" "),
              _c("input", {
                directives: [
                  {
                    name: "model",
                    rawName: "v-model",
                    value: _vm.$v.dataFlowItem.documentationURL.$model,
                    expression: "$v.dataFlowItem.documentationURL.$model",
                  },
                ],
                staticClass: "form-control",
                class: {
                  valid: !_vm.$v.dataFlowItem.documentationURL.$invalid,
                  invalid: _vm.$v.dataFlowItem.documentationURL.$invalid,
                },
                attrs: {
                  type: "text",
                  name: "documentationURL",
                  id: "data-flow-item-documentationURL",
                  "data-cy": "documentationURL",
                },
                domProps: {
                  value: _vm.$v.dataFlowItem.documentationURL.$model,
                },
                on: {
                  input: function ($event) {
                    if ($event.target.composing) {
                      return
                    }
                    _vm.$set(
                      _vm.$v.dataFlowItem.documentationURL,
                      "$model",
                      $event.target.value
                    )
                  },
                },
              }),
              _vm._v(" "),
              _vm.$v.dataFlowItem.documentationURL.$anyDirty &&
              _vm.$v.dataFlowItem.documentationURL.$invalid
                ? _c("div", [
                    !_vm.$v.dataFlowItem.documentationURL.maxLength
                      ? _c("small", { staticClass: "form-text text-danger" }, [
                          _vm._v(
                            "\n              This field cannot be longer than 500 characters.\n            "
                          ),
                        ])
                      : _vm._e(),
                  ])
                : _vm._e(),
            ]),
            _vm._v(" "),
            _c(
              "div",
              { staticClass: "form-group" },
              [
                _c(
                  "label",
                  {
                    staticClass: "form-control-label",
                    attrs: { for: "data-flow-item-startDate" },
                  },
                  [_vm._v("Start Date")]
                ),
                _vm._v(" "),
                _c(
                  "b-input-group",
                  { staticClass: "mb-3" },
                  [
                    _c(
                      "b-input-group-prepend",
                      [
                        _c("b-form-datepicker", {
                          staticClass: "form-control",
                          attrs: {
                            "aria-controls": "data-flow-item-startDate",
                            name: "startDate",
                            locale: _vm.currentLanguage,
                            "button-only": "",
                            "today-button": "",
                            "reset-button": "",
                            "close-button": "",
                          },
                          model: {
                            value: _vm.$v.dataFlowItem.startDate.$model,
                            callback: function ($$v) {
                              _vm.$set(
                                _vm.$v.dataFlowItem.startDate,
                                "$model",
                                $$v
                              )
                            },
                            expression: "$v.dataFlowItem.startDate.$model",
                          },
                        }),
                      ],
                      1
                    ),
                    _vm._v(" "),
                    _c("b-form-input", {
                      staticClass: "form-control",
                      class: {
                        valid: !_vm.$v.dataFlowItem.startDate.$invalid,
                        invalid: _vm.$v.dataFlowItem.startDate.$invalid,
                      },
                      attrs: {
                        id: "data-flow-item-startDate",
                        "data-cy": "startDate",
                        type: "text",
                        name: "startDate",
                      },
                      model: {
                        value: _vm.$v.dataFlowItem.startDate.$model,
                        callback: function ($$v) {
                          _vm.$set(_vm.$v.dataFlowItem.startDate, "$model", $$v)
                        },
                        expression: "$v.dataFlowItem.startDate.$model",
                      },
                    }),
                  ],
                  1
                ),
              ],
              1
            ),
            _vm._v(" "),
            _c(
              "div",
              { staticClass: "form-group" },
              [
                _c(
                  "label",
                  {
                    staticClass: "form-control-label",
                    attrs: { for: "data-flow-item-endDate" },
                  },
                  [_vm._v("End Date")]
                ),
                _vm._v(" "),
                _c(
                  "b-input-group",
                  { staticClass: "mb-3" },
                  [
                    _c(
                      "b-input-group-prepend",
                      [
                        _c("b-form-datepicker", {
                          staticClass: "form-control",
                          attrs: {
                            "aria-controls": "data-flow-item-endDate",
                            name: "endDate",
                            locale: _vm.currentLanguage,
                            "button-only": "",
                            "today-button": "",
                            "reset-button": "",
                            "close-button": "",
                          },
                          model: {
                            value: _vm.$v.dataFlowItem.endDate.$model,
                            callback: function ($$v) {
                              _vm.$set(
                                _vm.$v.dataFlowItem.endDate,
                                "$model",
                                $$v
                              )
                            },
                            expression: "$v.dataFlowItem.endDate.$model",
                          },
                        }),
                      ],
                      1
                    ),
                    _vm._v(" "),
                    _c("b-form-input", {
                      staticClass: "form-control",
                      class: {
                        valid: !_vm.$v.dataFlowItem.endDate.$invalid,
                        invalid: _vm.$v.dataFlowItem.endDate.$invalid,
                      },
                      attrs: {
                        id: "data-flow-item-endDate",
                        "data-cy": "endDate",
                        type: "text",
                        name: "endDate",
                      },
                      model: {
                        value: _vm.$v.dataFlowItem.endDate.$model,
                        callback: function ($$v) {
                          _vm.$set(_vm.$v.dataFlowItem.endDate, "$model", $$v)
                        },
                        expression: "$v.dataFlowItem.endDate.$model",
                      },
                    }),
                  ],
                  1
                ),
              ],
              1
            ),
            _vm._v(" "),
            _c("div", { staticClass: "form-group" }, [
              _c(
                "label",
                {
                  staticClass: "form-control-label",
                  attrs: { for: "data-flow-item-dataFlow" },
                },
                [_vm._v("Data Flow")]
              ),
              _vm._v(" "),
              _c(
                "select",
                {
                  directives: [
                    {
                      name: "model",
                      rawName: "v-model",
                      value: _vm.dataFlowItem.dataFlow,
                      expression: "dataFlowItem.dataFlow",
                    },
                  ],
                  staticClass: "form-control",
                  attrs: {
                    id: "data-flow-item-dataFlow",
                    "data-cy": "dataFlow",
                    name: "dataFlow",
                  },
                  on: {
                    change: function ($event) {
                      var $$selectedVal = Array.prototype.filter
                        .call($event.target.options, function (o) {
                          return o.selected
                        })
                        .map(function (o) {
                          var val = "_value" in o ? o._value : o.value
                          return val
                        })
                      _vm.$set(
                        _vm.dataFlowItem,
                        "dataFlow",
                        $event.target.multiple
                          ? $$selectedVal
                          : $$selectedVal[0]
                      )
                    },
                  },
                },
                [
                  _c("option", { domProps: { value: null } }),
                  _vm._v(" "),
                  _vm._l(_vm.dataFlows, function (dataFlowOption) {
                    return _c(
                      "option",
                      {
                        key: dataFlowOption.id,
                        domProps: {
                          value:
                            _vm.dataFlowItem.dataFlow &&
                            dataFlowOption.id === _vm.dataFlowItem.dataFlow.id
                              ? _vm.dataFlowItem.dataFlow
                              : dataFlowOption,
                        },
                      },
                      [
                        _vm._v(
                          "\n              " +
                            _vm._s(dataFlowOption.id) +
                            "\n            "
                        ),
                      ]
                    )
                  }),
                ],
                2
              ),
            ]),
          ]),
          _vm._v(" "),
          _c("div", [
            _c(
              "button",
              {
                staticClass: "btn btn-secondary",
                attrs: {
                  type: "button",
                  id: "cancel-save",
                  "data-cy": "entityCreateCancelButton",
                },
                on: {
                  click: function ($event) {
                    return _vm.previousState()
                  },
                },
              },
              [
                _c("font-awesome-icon", { attrs: { icon: "ban" } }),
                _vm._v(" "),
                _c("span", [_vm._v("Cancel")]),
              ],
              1
            ),
            _vm._v(" "),
            _c(
              "button",
              {
                staticClass: "btn btn-primary",
                attrs: {
                  type: "submit",
                  id: "save-entity",
                  "data-cy": "entityCreateSaveButton",
                  disabled: _vm.$v.dataFlowItem.$invalid || _vm.isSaving,
                },
              },
              [
                _c("font-awesome-icon", { attrs: { icon: "save" } }),
                _vm._v(" "),
                _c("span", [_vm._v("Save")]),
              ],
              1
            ),
          ]),
        ]
      ),
    ]),
  ])
}
var staticRenderFns = []
render._withStripped = true



/***/ })

}]);
//# sourceMappingURL=src_main_webapp_app_entities_data-flow-item_data-flow-item-update_vue.js.map