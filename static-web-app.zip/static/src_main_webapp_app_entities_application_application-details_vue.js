(self["webpackChunkea_design_it"] = self["webpackChunkea_design_it"] || []).push([["src_main_webapp_app_entities_application_application-details_vue"],{

/***/ "./node_modules/css-loader/dist/cjs.js??clonedRuleSet-3[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-3[0].rules[0].use[2]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./src/main/webapp/app/entities/application/application-details.vue?vue&type=style&index=0&id=a5da5b2a&scoped=true&lang=css&":
/*!***************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/css-loader/dist/cjs.js??clonedRuleSet-3[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-3[0].rules[0].use[2]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./src/main/webapp/app/entities/application/application-details.vue?vue&type=style&index=0&id=a5da5b2a&scoped=true&lang=css& ***!
  \***************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/***/ (function(module, __unused_webpack_exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_SOURCEMAP_IMPORT___ = __webpack_require__(/*! ../../../../../../node_modules/css-loader/dist/runtime/sourceMaps.js */ "./node_modules/css-loader/dist/runtime/sourceMaps.js");
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(/*! ../../../../../../node_modules/css-loader/dist/runtime/api.js */ "./node_modules/css-loader/dist/runtime/api.js");
var ___CSS_LOADER_EXPORT___ = ___CSS_LOADER_API_IMPORT___(___CSS_LOADER_API_SOURCEMAP_IMPORT___);
// Module
___CSS_LOADER_EXPORT___.push([module.id, "\n.common[data-v-a5da5b2a] {\n  font-weight: normal;\n  border: solid;\n  border-color: rgb(110, 110, 110);\n  border-width: 1px;\n  padding: 5px;\n  margin: 5px;\n  -webkit-box-shadow: 1px 1px 2px #aaa;\n          box-shadow: 1px 1px 2px #aaa;\n}\n.alpha[data-v-a5da5b2a] {\n  background-color: white;\n}\n.beta[data-v-a5da5b2a] {\n  background-color: #d0ecf0c4;\n  max-width: 300px;\n}\n.capatext[data-v-a5da5b2a] {\n  font-weight: normal;\n  color: rgb(59, 59, 59);\n}\n", "",{"version":3,"sources":["webpack://./src/main/webapp/app/entities/application/application-details.vue"],"names":[],"mappings":";AA0OA;EACA,mBAAA;EACA,aAAA;EACA,gCAAA;EACA,iBAAA;EACA,YAAA;EACA,WAAA;EACA,oCAAA;UAAA,4BAAA;AACA;AAEA;EACA,uBAAA;AACA;AAEA;EACA,2BAAA;EACA,gBAAA;AACA;AAEA;EACA,mBAAA;EACA,sBAAA;AACA","sourcesContent":["<template>\n  <div class=\"row justify-content-center\">\n    <div class=\"col-8\">\n      <div v-if=\"application\">\n        <h2 class=\"jh-entity-heading\" data-cy=\"applicationDetailsHeading\"><span>Application</span> - {{ application.name }}</h2>\n        <dl class=\"row jh-entity-details\">\n          <dt>\n            <span>Alias</span>\n          </dt>\n          <dd>\n            <span>{{ application.alias }}</span>\n          </dd>\n          <dt>\n            <span>Name</span>\n          </dt>\n          <dd>\n            <span>{{ application.name }}</span>\n          </dd>\n          <dt>\n            <span>Description</span>\n          </dt>\n          <dd>\n            <span>{{ application.description }}</span>\n          </dd>\n          <dt>\n            <span>Comment</span>\n          </dt>\n          <dd>\n            <span>{{ application.comment }}</span>\n          </dd>\n          <dt>\n            <span>Documentation URL</span>\n          </dt>\n          <dd>\n            <span\n              ><a v-bind:href=\"application.documentationURL\">{{ application.documentationURL }}</a></span\n            >\n          </dd>\n          <dt>\n            <span>Start Date</span>\n          </dt>\n          <dd>\n            <span>{{ application.startDate }}</span>\n          </dd>\n          <dt>\n            <span>End Date</span>\n          </dt>\n          <dd>\n            <span>{{ application.endDate }}</span>\n          </dd>\n          <dt>\n            <span>Application Type</span>\n          </dt>\n          <dd>\n            <span>{{ application.applicationType }}</span>\n          </dd>\n          <dt>\n            <span>Software Type</span>\n          </dt>\n          <dd>\n            <span>{{ application.softwareType }}</span>\n          </dd>\n          <dt>\n            <span>Owner</span>\n          </dt>\n          <dd>\n            <div v-if=\"application.owner\">\n              <router-link :to=\"{ name: 'OwnerView', params: { ownerId: application.owner.id } }\">{{ application.owner.name }}</router-link>\n            </div>\n          </dd>\n          <dt>\n            <span>Categories</span>\n          </dt>\n          <dd>\n            <span v-for=\"(categories, i) in application.categories\" :key=\"categories.id\"\n              >{{ i > 0 ? ', ' : '' }}\n              <router-link :to=\"{ name: 'ApplicationCategoryView', params: { applicationCategoryId: categories.id } }\">{{\n                categories.name\n              }}</router-link>\n            </span>\n          </dd>\n          <dt>\n            <span>Technologies</span>\n          </dt>\n          <dd>\n            <span v-for=\"(technologies, i) in application.technologies\" :key=\"technologies.id\"\n              >{{ i > 0 ? ', ' : '' }}\n              <router-link :to=\"{ name: 'TechnologyView', params: { technologyId: technologies.id } }\">{{ technologies.name }}</router-link>\n            </span>\n          </dd>\n        </dl>\n        <button type=\"submit\" v-on:click.prevent=\"previousState()\" class=\"btn btn-info\" data-cy=\"entityDetailsBackButton\">\n          <font-awesome-icon icon=\"arrow-left\"></font-awesome-icon>&nbsp;<span> Back</span>\n        </button>\n        <router-link\n          v-if=\"application.id\"\n          :to=\"{ name: 'ApplicationEdit', params: { applicationId: application.id } }\"\n          custom\n          v-slot=\"{ navigate }\"\n        >\n          <button @click=\"navigate\" class=\"btn btn-primary\" v-if=\"accountService().writeOrContributor\" :disabled=\"!isOwner(application)\">\n            <font-awesome-icon icon=\"pencil-alt\"></font-awesome-icon>&nbsp;<span> Edit</span>\n          </button>\n        </router-link>\n      </div>\n      <br />\n      <h2>Interfaces for {{ application.name }}</h2>\n      <div v-html=\"plantUMLImage\" class=\"table-responsive\"></div>\n      <div class=\"col-12\">\n        <button\n          class=\"btn btn-secondary\"\n          v-on:click=\"changeLayout()\"\n          style=\"font-size: 0.7em; padding: 3px; margin: 3px\"\n          v-if=\"plantUMLImage\"\n          :disabled=\"refreshingPlantuml\"\n        >\n          <font-awesome-icon icon=\"sync\" :spin=\"refreshingPlantuml\"></font-awesome-icon>\n          <span>Change Layout ({{ layout }})</span>\n        </button>\n        <button\n          class=\"btn btn-secondary\"\n          v-on:click=\"doGroupComponents()\"\n          style=\"font-size: 0.7em; padding: 3px; margin: 3px\"\n          v-if=\"plantUMLImage\"\n          :disabled=\"refreshingPlantuml\"\n        >\n          <font-awesome-icon icon=\"sync\" :spin=\"refreshingPlantuml\"></font-awesome-icon>\n          <span>{{ groupComponents ? 'Ungroup Components' : 'Group components' }} </span>\n        </button>\n        <br /><br />\n      </div>\n      <table class=\"table\">\n        <thead>\n          <tr>\n            <th scope=\"row\"><span>Interface</span></th>\n            <th scope=\"row\"><span>Source</span></th>\n            <th scope=\"row\"><span>Target</span></th>\n            <th scope=\"row\"><span>Protocol</span></th>\n            <th scope=\"row\"></th>\n          </tr>\n        </thead>\n        <tbody>\n          <tr v-for=\"caption in interfaces\" v-bind:key=\"caption.id\">\n            <td>\n              <router-link :to=\"{ name: 'FlowInterfaceView', params: { flowInterfaceId: caption.id } }\">{{ caption.alias }}</router-link>\n            </td>\n            <td>\n              <a v-on:click=\"retrieveApplication(caption.source.id)\">{{ caption.source.name }}</a>\n            </td>\n            <td>\n              <a v-on:click=\"retrieveApplication(caption.target.id)\">{{ caption.target.name }}</a>\n            </td>\n            <td>\n              <router-link v-if=\"caption.protocol\" :to=\"{ name: 'ProtocolView', params: { protocolId: caption.protocol.id } }\">\n                {{ caption.protocol.name }}\n              </router-link>\n            </td>\n          </tr>\n        </tbody>\n      </table>\n    </div>\n    <div class=\"col-8\" v-if=\"consolidatedCapabilities.length > 0\">\n      <h2>Capabilities for {{ application.name }}</h2>\n      <div\n        v-for=\"capability in consolidatedCapabilities\"\n        :key=\"capability.id\"\n        class=\"common\"\n        :class=\"capability.subCapabilities.length > 0 ? 'alpha' : 'beta'\"\n      >\n        <div :title=\"capability.description\">\n          <router-link\n            :to=\"{ name: 'CapabilityView', params: { capabilityId: capability.id } }\"\n            :title=\"capability.description\"\n            class=\"capatext\"\n            >{{ capability.name }}</router-link\n          >\n        </div>\n        <div v-if=\"capability.subCapabilities\" class=\"d-flex flex-wrap\">\n          <div\n            v-for=\"child1 in capability.subCapabilities\"\n            :key=\"child1.id\"\n            class=\"common\"\n            :class=\"child1.subCapabilities.length > 0 ? 'alpha' : 'beta'\"\n          >\n            <div :title=\"child1.description\">\n              <router-link\n                :to=\"{ name: 'CapabilityView', params: { capabilityId: child1.id } }\"\n                :title=\"child1.description\"\n                class=\"capatext\"\n                >{{ child1.name }}</router-link\n              >\n            </div>\n            <div v-if=\"child1.subCapabilities\" class=\"d-flex flex-wrap\">\n              <div\n                v-for=\"child2 in child1.subCapabilities\"\n                :key=\"child2.id\"\n                class=\"common\"\n                :class=\"child2.subCapabilities.length > 0 ? 'alpha' : 'beta'\"\n              >\n                <div>\n                  <router-link\n                    :to=\"{ name: 'CapabilityView', params: { capabilityId: child2.id } }\"\n                    :title=\"child2.description\"\n                    class=\"capatext\"\n                    >{{ child2.name }}</router-link\n                  >\n                </div>\n                <div v-if=\"child2.subCapabilities\" class=\"d-flex flex-wrap\">\n                  <div\n                    v-for=\"child3 in child2.subCapabilities\"\n                    :key=\"child3.id\"\n                    class=\"common\"\n                    :class=\"child3.subCapabilities.length > 0 ? 'alpha' : 'beta'\"\n                  >\n                    <div>\n                      <router-link\n                        :to=\"{ name: 'CapabilityView', params: { capabilityId: child3.id } }\"\n                        :title=\"child3.description\"\n                        class=\"capatext\"\n                        >{{ child3.name }}</router-link\n                      >\n                    </div>\n                  </div>\n                </div>\n              </div>\n            </div>\n          </div>\n        </div>\n      </div>\n    </div>\n  </div>\n</template>\n\n<style scoped>\n.common {\n  font-weight: normal;\n  border: solid;\n  border-color: rgb(110, 110, 110);\n  border-width: 1px;\n  padding: 5px;\n  margin: 5px;\n  box-shadow: 1px 1px 2px #aaa;\n}\n\n.alpha {\n  background-color: white;\n}\n\n.beta {\n  background-color: #d0ecf0c4;\n  max-width: 300px;\n}\n\n.capatext {\n  font-weight: normal;\n  color: rgb(59, 59, 59);\n}\n</style>\n\n<script lang=\"ts\" src=\"./application-details.component.ts\"></script>\n"],"sourceRoot":""}]);
// Exports
module.exports = ___CSS_LOADER_EXPORT___;


/***/ }),

/***/ "./node_modules/ts-loader/index.js??clonedRuleSet-1[0].rules[0].use[0]!./src/main/webapp/app/entities/application/application-details.component.ts?vue&type=script&lang=ts&":
/*!**********************************************************************************************************************************************************************************!*\
  !*** ./node_modules/ts-loader/index.js??clonedRuleSet-1[0].rules[0].use[0]!./src/main/webapp/app/entities/application/application-details.component.ts?vue&type=script&lang=ts& ***!
  \**********************************************************************************************************************************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var vue_property_decorator__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! vue-property-decorator */ "./node_modules/vue-property-decorator/lib/index.js");
var __extends = (undefined && undefined.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        if (typeof b !== "function" && b !== null)
            throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};

var ApplicationDetails = /** @class */ (function (_super) {
    __extends(ApplicationDetails, _super);
    function ApplicationDetails() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.application = {};
        _this.plantUMLImage = '';
        _this.capabilitiesPlantUMLImage = '';
        _this.interfaces = [];
        _this.consolidatedCapabilities = [];
        _this.layout = 'smetana';
        _this.refreshingPlantuml = false;
        _this.groupComponents = true;
        return _this;
    }
    ApplicationDetails.prototype.beforeRouteEnter = function (to, from, next) {
        next(function (vm) {
            if (to.params.applicationId) {
                vm.retrieveApplication(to.params.applicationId);
            }
        });
    };
    ApplicationDetails.prototype.retrieveApplication = function (applicationId) {
        var _this = this;
        this.plantUMLImage = '';
        this.capabilitiesPlantUMLImage = '';
        this.applicationService()
            .find(applicationId)
            .then(function (res) {
            _this.application = res;
            _this.getPlantUML(applicationId);
            _this.retrieveCapabilities(applicationId);
        })
            .catch(function (error) {
            _this.alertService().showHttpError(_this, error.response);
        });
    };
    ApplicationDetails.prototype.previousState = function () {
        this.$router.go(-1);
    };
    ApplicationDetails.prototype.getPlantUML = function (applicationId) {
        var _this = this;
        this.applicationService()
            .getPlantUML(applicationId, this.layout, this.groupComponents)
            .then(function (res) {
            _this.plantUMLImage = res.data.svg;
            _this.interfaces = res.data.interfaces;
            _this.refreshingPlantuml = false;
        }, function (err) {
            console.log(err);
        });
    };
    ApplicationDetails.prototype.isOwner = function (application) {
        var _a, _b;
        var username = (_b = (_a = this.$store.getters.account) === null || _a === void 0 ? void 0 : _a.login) !== null && _b !== void 0 ? _b : '';
        if (this.accountService().writeAuthorities) {
            return true;
        }
        if (application.owner && application.owner.users) {
            for (var _i = 0, _c = application.owner.users; _i < _c.length; _i++) {
                var user = _c[_i];
                if (user.login === username) {
                    return true;
                }
            }
        }
        return false;
    };
    ApplicationDetails.prototype.retrieveCapabilities = function (applicationId) {
        var _this = this;
        this.applicationService()
            .getCapabilities(applicationId)
            .then(function (res) {
            _this.consolidatedCapabilities = res;
        })
            .catch(function (error) {
            _this.alertService().showHttpError(_this, error.response);
        });
    };
    ApplicationDetails.prototype.exportPlantUML = function () {
        var _this = this;
        this.applicationService()
            .getPlantUMLSource(this.landscapeView.id)
            .then(function (response) {
            var url = URL.createObjectURL(new Blob([response.data], {
                type: 'text/plain',
            }));
            var link = document.createElement('a');
            link.href = url;
            link.setAttribute('download', _this.landscapeView.diagramName + '-plantuml.txt');
            document.body.appendChild(link);
            link.click();
        });
    };
    ApplicationDetails.prototype.changeLayout = function () {
        if (this.layout == 'smetana') {
            this.layout = 'elk';
        }
        else {
            this.layout = 'smetana';
        }
        this.getPlantUML(this.application.id);
    };
    ApplicationDetails.prototype.doGroupComponents = function () {
        this.refreshingPlantuml = true;
        this.groupComponents = !this.groupComponents;
        this.getPlantUML(this.application.id);
    };
    __decorate([
        (0,vue_property_decorator__WEBPACK_IMPORTED_MODULE_0__.Inject)('applicationService'),
        __metadata("design:type", Function)
    ], ApplicationDetails.prototype, "applicationService", void 0);
    __decorate([
        (0,vue_property_decorator__WEBPACK_IMPORTED_MODULE_0__.Inject)('alertService'),
        __metadata("design:type", Function)
    ], ApplicationDetails.prototype, "alertService", void 0);
    __decorate([
        (0,vue_property_decorator__WEBPACK_IMPORTED_MODULE_0__.Inject)('accountService'),
        __metadata("design:type", Function)
    ], ApplicationDetails.prototype, "accountService", void 0);
    ApplicationDetails = __decorate([
        vue_property_decorator__WEBPACK_IMPORTED_MODULE_0__.Component
    ], ApplicationDetails);
    return ApplicationDetails;
}(vue_property_decorator__WEBPACK_IMPORTED_MODULE_0__.Vue));
/* harmony default export */ __webpack_exports__["default"] = (ApplicationDetails);


/***/ }),

/***/ "./src/main/webapp/app/entities/application/application-details.vue":
/*!**************************************************************************!*\
  !*** ./src/main/webapp/app/entities/application/application-details.vue ***!
  \**************************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _application_details_vue_vue_type_template_id_a5da5b2a_scoped_true___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./application-details.vue?vue&type=template&id=a5da5b2a&scoped=true& */ "./src/main/webapp/app/entities/application/application-details.vue?vue&type=template&id=a5da5b2a&scoped=true&");
/* harmony import */ var _application_details_component_ts_vue_type_script_lang_ts___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./application-details.component.ts?vue&type=script&lang=ts& */ "./src/main/webapp/app/entities/application/application-details.component.ts?vue&type=script&lang=ts&");
/* harmony import */ var _application_details_vue_vue_type_style_index_0_id_a5da5b2a_scoped_true_lang_css___WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./application-details.vue?vue&type=style&index=0&id=a5da5b2a&scoped=true&lang=css& */ "./src/main/webapp/app/entities/application/application-details.vue?vue&type=style&index=0&id=a5da5b2a&scoped=true&lang=css&");
/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! !../../../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");



;


/* normalize component */

var component = (0,_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__["default"])(
  _application_details_component_ts_vue_type_script_lang_ts___WEBPACK_IMPORTED_MODULE_1__["default"],
  _application_details_vue_vue_type_template_id_a5da5b2a_scoped_true___WEBPACK_IMPORTED_MODULE_0__.render,
  _application_details_vue_vue_type_template_id_a5da5b2a_scoped_true___WEBPACK_IMPORTED_MODULE_0__.staticRenderFns,
  false,
  null,
  "a5da5b2a",
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "src/main/webapp/app/entities/application/application-details.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./src/main/webapp/app/entities/application/application-details.component.ts?vue&type=script&lang=ts&":
/*!************************************************************************************************************!*\
  !*** ./src/main/webapp/app/entities/application/application-details.component.ts?vue&type=script&lang=ts& ***!
  \************************************************************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_ts_loader_index_js_clonedRuleSet_1_0_rules_0_use_0_application_details_component_ts_vue_type_script_lang_ts___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../../node_modules/ts-loader/index.js??clonedRuleSet-1[0].rules[0].use[0]!./application-details.component.ts?vue&type=script&lang=ts& */ "./node_modules/ts-loader/index.js??clonedRuleSet-1[0].rules[0].use[0]!./src/main/webapp/app/entities/application/application-details.component.ts?vue&type=script&lang=ts&");
 /* harmony default export */ __webpack_exports__["default"] = (_node_modules_ts_loader_index_js_clonedRuleSet_1_0_rules_0_use_0_application_details_component_ts_vue_type_script_lang_ts___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./src/main/webapp/app/entities/application/application-details.vue?vue&type=template&id=a5da5b2a&scoped=true&":
/*!*********************************************************************************************************************!*\
  !*** ./src/main/webapp/app/entities/application/application-details.vue?vue&type=template&id=a5da5b2a&scoped=true& ***!
  \*********************************************************************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": function() { return /* reexport safe */ _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_application_details_vue_vue_type_template_id_a5da5b2a_scoped_true___WEBPACK_IMPORTED_MODULE_0__.render; },
/* harmony export */   "staticRenderFns": function() { return /* reexport safe */ _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_application_details_vue_vue_type_template_id_a5da5b2a_scoped_true___WEBPACK_IMPORTED_MODULE_0__.staticRenderFns; }
/* harmony export */ });
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_application_details_vue_vue_type_template_id_a5da5b2a_scoped_true___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./application-details.vue?vue&type=template&id=a5da5b2a&scoped=true& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./src/main/webapp/app/entities/application/application-details.vue?vue&type=template&id=a5da5b2a&scoped=true&");


/***/ }),

/***/ "./src/main/webapp/app/entities/application/application-details.vue?vue&type=style&index=0&id=a5da5b2a&scoped=true&lang=css&":
/*!***********************************************************************************************************************************!*\
  !*** ./src/main/webapp/app/entities/application/application-details.vue?vue&type=style&index=0&id=a5da5b2a&scoped=true&lang=css& ***!
  \***********************************************************************************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_style_loader_index_js_node_modules_css_loader_dist_cjs_js_clonedRuleSet_3_0_rules_0_use_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_clonedRuleSet_3_0_rules_0_use_2_node_modules_vue_loader_lib_index_js_vue_loader_options_application_details_vue_vue_type_style_index_0_id_a5da5b2a_scoped_true_lang_css___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../../node_modules/vue-style-loader/index.js!../../../../../../node_modules/css-loader/dist/cjs.js??clonedRuleSet-3[0].rules[0].use[1]!../../../../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../../../../node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-3[0].rules[0].use[2]!../../../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./application-details.vue?vue&type=style&index=0&id=a5da5b2a&scoped=true&lang=css& */ "./node_modules/vue-style-loader/index.js!./node_modules/css-loader/dist/cjs.js??clonedRuleSet-3[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-3[0].rules[0].use[2]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./src/main/webapp/app/entities/application/application-details.vue?vue&type=style&index=0&id=a5da5b2a&scoped=true&lang=css&");
/* harmony import */ var _node_modules_vue_style_loader_index_js_node_modules_css_loader_dist_cjs_js_clonedRuleSet_3_0_rules_0_use_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_clonedRuleSet_3_0_rules_0_use_2_node_modules_vue_loader_lib_index_js_vue_loader_options_application_details_vue_vue_type_style_index_0_id_a5da5b2a_scoped_true_lang_css___WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_vue_style_loader_index_js_node_modules_css_loader_dist_cjs_js_clonedRuleSet_3_0_rules_0_use_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_clonedRuleSet_3_0_rules_0_use_2_node_modules_vue_loader_lib_index_js_vue_loader_options_application_details_vue_vue_type_style_index_0_id_a5da5b2a_scoped_true_lang_css___WEBPACK_IMPORTED_MODULE_0__);
/* harmony reexport (unknown) */ var __WEBPACK_REEXPORT_OBJECT__ = {};
/* harmony reexport (unknown) */ for(var __WEBPACK_IMPORT_KEY__ in _node_modules_vue_style_loader_index_js_node_modules_css_loader_dist_cjs_js_clonedRuleSet_3_0_rules_0_use_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_clonedRuleSet_3_0_rules_0_use_2_node_modules_vue_loader_lib_index_js_vue_loader_options_application_details_vue_vue_type_style_index_0_id_a5da5b2a_scoped_true_lang_css___WEBPACK_IMPORTED_MODULE_0__) if(__WEBPACK_IMPORT_KEY__ !== "default") __WEBPACK_REEXPORT_OBJECT__[__WEBPACK_IMPORT_KEY__] = function(key) { return _node_modules_vue_style_loader_index_js_node_modules_css_loader_dist_cjs_js_clonedRuleSet_3_0_rules_0_use_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_clonedRuleSet_3_0_rules_0_use_2_node_modules_vue_loader_lib_index_js_vue_loader_options_application_details_vue_vue_type_style_index_0_id_a5da5b2a_scoped_true_lang_css___WEBPACK_IMPORTED_MODULE_0__[key]; }.bind(0, __WEBPACK_IMPORT_KEY__)
/* harmony reexport (unknown) */ __webpack_require__.d(__webpack_exports__, __WEBPACK_REEXPORT_OBJECT__);


/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./src/main/webapp/app/entities/application/application-details.vue?vue&type=template&id=a5da5b2a&scoped=true&":
/*!************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./src/main/webapp/app/entities/application/application-details.vue?vue&type=template&id=a5da5b2a&scoped=true& ***!
  \************************************************************************************************************************************************************************************************************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": function() { return /* binding */ render; },
/* harmony export */   "staticRenderFns": function() { return /* binding */ staticRenderFns; }
/* harmony export */ });
var render = function () {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c("div", { staticClass: "row justify-content-center" }, [
    _c("div", { staticClass: "col-8" }, [
      _vm.application
        ? _c(
            "div",
            [
              _c(
                "h2",
                {
                  staticClass: "jh-entity-heading",
                  attrs: { "data-cy": "applicationDetailsHeading" },
                },
                [
                  _c("span", [_vm._v("Application")]),
                  _vm._v(" - " + _vm._s(_vm.application.name)),
                ]
              ),
              _vm._v(" "),
              _c("dl", { staticClass: "row jh-entity-details" }, [
                _vm._m(0),
                _vm._v(" "),
                _c("dd", [_c("span", [_vm._v(_vm._s(_vm.application.alias))])]),
                _vm._v(" "),
                _vm._m(1),
                _vm._v(" "),
                _c("dd", [_c("span", [_vm._v(_vm._s(_vm.application.name))])]),
                _vm._v(" "),
                _vm._m(2),
                _vm._v(" "),
                _c("dd", [
                  _c("span", [_vm._v(_vm._s(_vm.application.description))]),
                ]),
                _vm._v(" "),
                _vm._m(3),
                _vm._v(" "),
                _c("dd", [
                  _c("span", [_vm._v(_vm._s(_vm.application.comment))]),
                ]),
                _vm._v(" "),
                _vm._m(4),
                _vm._v(" "),
                _c("dd", [
                  _c("span", [
                    _c(
                      "a",
                      { attrs: { href: _vm.application.documentationURL } },
                      [_vm._v(_vm._s(_vm.application.documentationURL))]
                    ),
                  ]),
                ]),
                _vm._v(" "),
                _vm._m(5),
                _vm._v(" "),
                _c("dd", [
                  _c("span", [_vm._v(_vm._s(_vm.application.startDate))]),
                ]),
                _vm._v(" "),
                _vm._m(6),
                _vm._v(" "),
                _c("dd", [
                  _c("span", [_vm._v(_vm._s(_vm.application.endDate))]),
                ]),
                _vm._v(" "),
                _vm._m(7),
                _vm._v(" "),
                _c("dd", [
                  _c("span", [_vm._v(_vm._s(_vm.application.applicationType))]),
                ]),
                _vm._v(" "),
                _vm._m(8),
                _vm._v(" "),
                _c("dd", [
                  _c("span", [_vm._v(_vm._s(_vm.application.softwareType))]),
                ]),
                _vm._v(" "),
                _vm._m(9),
                _vm._v(" "),
                _c("dd", [
                  _vm.application.owner
                    ? _c(
                        "div",
                        [
                          _c(
                            "router-link",
                            {
                              attrs: {
                                to: {
                                  name: "OwnerView",
                                  params: { ownerId: _vm.application.owner.id },
                                },
                              },
                            },
                            [_vm._v(_vm._s(_vm.application.owner.name))]
                          ),
                        ],
                        1
                      )
                    : _vm._e(),
                ]),
                _vm._v(" "),
                _vm._m(10),
                _vm._v(" "),
                _c(
                  "dd",
                  _vm._l(_vm.application.categories, function (categories, i) {
                    return _c(
                      "span",
                      { key: categories.id },
                      [
                        _vm._v(_vm._s(i > 0 ? ", " : "") + "\n            "),
                        _c(
                          "router-link",
                          {
                            attrs: {
                              to: {
                                name: "ApplicationCategoryView",
                                params: {
                                  applicationCategoryId: categories.id,
                                },
                              },
                            },
                          },
                          [_vm._v(_vm._s(categories.name))]
                        ),
                      ],
                      1
                    )
                  }),
                  0
                ),
                _vm._v(" "),
                _vm._m(11),
                _vm._v(" "),
                _c(
                  "dd",
                  _vm._l(
                    _vm.application.technologies,
                    function (technologies, i) {
                      return _c(
                        "span",
                        { key: technologies.id },
                        [
                          _vm._v(_vm._s(i > 0 ? ", " : "") + "\n            "),
                          _c(
                            "router-link",
                            {
                              attrs: {
                                to: {
                                  name: "TechnologyView",
                                  params: { technologyId: technologies.id },
                                },
                              },
                            },
                            [_vm._v(_vm._s(technologies.name))]
                          ),
                        ],
                        1
                      )
                    }
                  ),
                  0
                ),
              ]),
              _vm._v(" "),
              _c(
                "button",
                {
                  staticClass: "btn btn-info",
                  attrs: {
                    type: "submit",
                    "data-cy": "entityDetailsBackButton",
                  },
                  on: {
                    click: function ($event) {
                      $event.preventDefault()
                      return _vm.previousState()
                    },
                  },
                },
                [
                  _c("font-awesome-icon", { attrs: { icon: "arrow-left" } }),
                  _vm._v(" "),
                  _c("span", [_vm._v(" Back")]),
                ],
                1
              ),
              _vm._v(" "),
              _vm.application.id
                ? _c("router-link", {
                    attrs: {
                      to: {
                        name: "ApplicationEdit",
                        params: { applicationId: _vm.application.id },
                      },
                      custom: "",
                    },
                    scopedSlots: _vm._u(
                      [
                        {
                          key: "default",
                          fn: function (ref) {
                            var navigate = ref.navigate
                            return [
                              _vm.accountService().writeOrContributor
                                ? _c(
                                    "button",
                                    {
                                      staticClass: "btn btn-primary",
                                      attrs: {
                                        disabled: !_vm.isOwner(_vm.application),
                                      },
                                      on: { click: navigate },
                                    },
                                    [
                                      _c("font-awesome-icon", {
                                        attrs: { icon: "pencil-alt" },
                                      }),
                                      _vm._v(" "),
                                      _c("span", [_vm._v(" Edit")]),
                                    ],
                                    1
                                  )
                                : _vm._e(),
                            ]
                          },
                        },
                      ],
                      null,
                      false,
                      4179178309
                    ),
                  })
                : _vm._e(),
            ],
            1
          )
        : _vm._e(),
      _vm._v(" "),
      _c("br"),
      _vm._v(" "),
      _c("h2", [_vm._v("Interfaces for " + _vm._s(_vm.application.name))]),
      _vm._v(" "),
      _c("div", {
        staticClass: "table-responsive",
        domProps: { innerHTML: _vm._s(_vm.plantUMLImage) },
      }),
      _vm._v(" "),
      _c("div", { staticClass: "col-12" }, [
        _vm.plantUMLImage
          ? _c(
              "button",
              {
                staticClass: "btn btn-secondary",
                staticStyle: {
                  "font-size": "0.7em",
                  padding: "3px",
                  margin: "3px",
                },
                attrs: { disabled: _vm.refreshingPlantuml },
                on: {
                  click: function ($event) {
                    return _vm.changeLayout()
                  },
                },
              },
              [
                _c("font-awesome-icon", {
                  attrs: { icon: "sync", spin: _vm.refreshingPlantuml },
                }),
                _vm._v(" "),
                _c("span", [
                  _vm._v("Change Layout (" + _vm._s(_vm.layout) + ")"),
                ]),
              ],
              1
            )
          : _vm._e(),
        _vm._v(" "),
        _vm.plantUMLImage
          ? _c(
              "button",
              {
                staticClass: "btn btn-secondary",
                staticStyle: {
                  "font-size": "0.7em",
                  padding: "3px",
                  margin: "3px",
                },
                attrs: { disabled: _vm.refreshingPlantuml },
                on: {
                  click: function ($event) {
                    return _vm.doGroupComponents()
                  },
                },
              },
              [
                _c("font-awesome-icon", {
                  attrs: { icon: "sync", spin: _vm.refreshingPlantuml },
                }),
                _vm._v(" "),
                _c("span", [
                  _vm._v(
                    _vm._s(
                      _vm.groupComponents
                        ? "Ungroup Components"
                        : "Group components"
                    ) + " "
                  ),
                ]),
              ],
              1
            )
          : _vm._e(),
        _vm._v(" "),
        _c("br"),
        _c("br"),
      ]),
      _vm._v(" "),
      _c("table", { staticClass: "table" }, [
        _vm._m(12),
        _vm._v(" "),
        _c(
          "tbody",
          _vm._l(_vm.interfaces, function (caption) {
            return _c("tr", { key: caption.id }, [
              _c(
                "td",
                [
                  _c(
                    "router-link",
                    {
                      attrs: {
                        to: {
                          name: "FlowInterfaceView",
                          params: { flowInterfaceId: caption.id },
                        },
                      },
                    },
                    [_vm._v(_vm._s(caption.alias))]
                  ),
                ],
                1
              ),
              _vm._v(" "),
              _c("td", [
                _c(
                  "a",
                  {
                    on: {
                      click: function ($event) {
                        return _vm.retrieveApplication(caption.source.id)
                      },
                    },
                  },
                  [_vm._v(_vm._s(caption.source.name))]
                ),
              ]),
              _vm._v(" "),
              _c("td", [
                _c(
                  "a",
                  {
                    on: {
                      click: function ($event) {
                        return _vm.retrieveApplication(caption.target.id)
                      },
                    },
                  },
                  [_vm._v(_vm._s(caption.target.name))]
                ),
              ]),
              _vm._v(" "),
              _c(
                "td",
                [
                  caption.protocol
                    ? _c(
                        "router-link",
                        {
                          attrs: {
                            to: {
                              name: "ProtocolView",
                              params: { protocolId: caption.protocol.id },
                            },
                          },
                        },
                        [
                          _vm._v(
                            "\n              " +
                              _vm._s(caption.protocol.name) +
                              "\n            "
                          ),
                        ]
                      )
                    : _vm._e(),
                ],
                1
              ),
            ])
          }),
          0
        ),
      ]),
    ]),
    _vm._v(" "),
    _vm.consolidatedCapabilities.length > 0
      ? _c(
          "div",
          { staticClass: "col-8" },
          [
            _c("h2", [
              _vm._v("Capabilities for " + _vm._s(_vm.application.name)),
            ]),
            _vm._v(" "),
            _vm._l(_vm.consolidatedCapabilities, function (capability) {
              return _c(
                "div",
                {
                  key: capability.id,
                  staticClass: "common",
                  class:
                    capability.subCapabilities.length > 0 ? "alpha" : "beta",
                },
                [
                  _c(
                    "div",
                    { attrs: { title: capability.description } },
                    [
                      _c(
                        "router-link",
                        {
                          staticClass: "capatext",
                          attrs: {
                            to: {
                              name: "CapabilityView",
                              params: { capabilityId: capability.id },
                            },
                            title: capability.description,
                          },
                        },
                        [_vm._v(_vm._s(capability.name))]
                      ),
                    ],
                    1
                  ),
                  _vm._v(" "),
                  capability.subCapabilities
                    ? _c(
                        "div",
                        { staticClass: "d-flex flex-wrap" },
                        _vm._l(capability.subCapabilities, function (child1) {
                          return _c(
                            "div",
                            {
                              key: child1.id,
                              staticClass: "common",
                              class:
                                child1.subCapabilities.length > 0
                                  ? "alpha"
                                  : "beta",
                            },
                            [
                              _c(
                                "div",
                                { attrs: { title: child1.description } },
                                [
                                  _c(
                                    "router-link",
                                    {
                                      staticClass: "capatext",
                                      attrs: {
                                        to: {
                                          name: "CapabilityView",
                                          params: { capabilityId: child1.id },
                                        },
                                        title: child1.description,
                                      },
                                    },
                                    [_vm._v(_vm._s(child1.name))]
                                  ),
                                ],
                                1
                              ),
                              _vm._v(" "),
                              child1.subCapabilities
                                ? _c(
                                    "div",
                                    { staticClass: "d-flex flex-wrap" },
                                    _vm._l(
                                      child1.subCapabilities,
                                      function (child2) {
                                        return _c(
                                          "div",
                                          {
                                            key: child2.id,
                                            staticClass: "common",
                                            class:
                                              child2.subCapabilities.length > 0
                                                ? "alpha"
                                                : "beta",
                                          },
                                          [
                                            _c(
                                              "div",
                                              [
                                                _c(
                                                  "router-link",
                                                  {
                                                    staticClass: "capatext",
                                                    attrs: {
                                                      to: {
                                                        name: "CapabilityView",
                                                        params: {
                                                          capabilityId:
                                                            child2.id,
                                                        },
                                                      },
                                                      title: child2.description,
                                                    },
                                                  },
                                                  [_vm._v(_vm._s(child2.name))]
                                                ),
                                              ],
                                              1
                                            ),
                                            _vm._v(" "),
                                            child2.subCapabilities
                                              ? _c(
                                                  "div",
                                                  {
                                                    staticClass:
                                                      "d-flex flex-wrap",
                                                  },
                                                  _vm._l(
                                                    child2.subCapabilities,
                                                    function (child3) {
                                                      return _c(
                                                        "div",
                                                        {
                                                          key: child3.id,
                                                          staticClass: "common",
                                                          class:
                                                            child3
                                                              .subCapabilities
                                                              .length > 0
                                                              ? "alpha"
                                                              : "beta",
                                                        },
                                                        [
                                                          _c(
                                                            "div",
                                                            [
                                                              _c(
                                                                "router-link",
                                                                {
                                                                  staticClass:
                                                                    "capatext",
                                                                  attrs: {
                                                                    to: {
                                                                      name: "CapabilityView",
                                                                      params: {
                                                                        capabilityId:
                                                                          child3.id,
                                                                      },
                                                                    },
                                                                    title:
                                                                      child3.description,
                                                                  },
                                                                },
                                                                [
                                                                  _vm._v(
                                                                    _vm._s(
                                                                      child3.name
                                                                    )
                                                                  ),
                                                                ]
                                                              ),
                                                            ],
                                                            1
                                                          ),
                                                        ]
                                                      )
                                                    }
                                                  ),
                                                  0
                                                )
                                              : _vm._e(),
                                          ]
                                        )
                                      }
                                    ),
                                    0
                                  )
                                : _vm._e(),
                            ]
                          )
                        }),
                        0
                      )
                    : _vm._e(),
                ]
              )
            }),
          ],
          2
        )
      : _vm._e(),
  ])
}
var staticRenderFns = [
  function () {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("dt", [_c("span", [_vm._v("Alias")])])
  },
  function () {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("dt", [_c("span", [_vm._v("Name")])])
  },
  function () {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("dt", [_c("span", [_vm._v("Description")])])
  },
  function () {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("dt", [_c("span", [_vm._v("Comment")])])
  },
  function () {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("dt", [_c("span", [_vm._v("Documentation URL")])])
  },
  function () {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("dt", [_c("span", [_vm._v("Start Date")])])
  },
  function () {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("dt", [_c("span", [_vm._v("End Date")])])
  },
  function () {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("dt", [_c("span", [_vm._v("Application Type")])])
  },
  function () {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("dt", [_c("span", [_vm._v("Software Type")])])
  },
  function () {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("dt", [_c("span", [_vm._v("Owner")])])
  },
  function () {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("dt", [_c("span", [_vm._v("Categories")])])
  },
  function () {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("dt", [_c("span", [_vm._v("Technologies")])])
  },
  function () {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("thead", [
      _c("tr", [
        _c("th", { attrs: { scope: "row" } }, [
          _c("span", [_vm._v("Interface")]),
        ]),
        _vm._v(" "),
        _c("th", { attrs: { scope: "row" } }, [_c("span", [_vm._v("Source")])]),
        _vm._v(" "),
        _c("th", { attrs: { scope: "row" } }, [_c("span", [_vm._v("Target")])]),
        _vm._v(" "),
        _c("th", { attrs: { scope: "row" } }, [
          _c("span", [_vm._v("Protocol")]),
        ]),
        _vm._v(" "),
        _c("th", { attrs: { scope: "row" } }),
      ]),
    ])
  },
]
render._withStripped = true



/***/ }),

/***/ "./node_modules/vue-style-loader/index.js!./node_modules/css-loader/dist/cjs.js??clonedRuleSet-3[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-3[0].rules[0].use[2]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./src/main/webapp/app/entities/application/application-details.vue?vue&type=style&index=0&id=a5da5b2a&scoped=true&lang=css&":
/*!********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-style-loader/index.js!./node_modules/css-loader/dist/cjs.js??clonedRuleSet-3[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-3[0].rules[0].use[2]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./src/main/webapp/app/entities/application/application-details.vue?vue&type=style&index=0&id=a5da5b2a&scoped=true&lang=css& ***!
  \********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/***/ (function(module, __unused_webpack_exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__(/*! !!../../../../../../node_modules/css-loader/dist/cjs.js??clonedRuleSet-3[0].rules[0].use[1]!../../../../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../../../../node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-3[0].rules[0].use[2]!../../../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./application-details.vue?vue&type=style&index=0&id=a5da5b2a&scoped=true&lang=css& */ "./node_modules/css-loader/dist/cjs.js??clonedRuleSet-3[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-3[0].rules[0].use[2]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./src/main/webapp/app/entities/application/application-details.vue?vue&type=style&index=0&id=a5da5b2a&scoped=true&lang=css&");
if(content.__esModule) content = content.default;
if(typeof content === 'string') content = [[module.id, content, '']];
if(content.locals) module.exports = content.locals;
// add the styles to the DOM
var add = (__webpack_require__(/*! !../../../../../../node_modules/vue-style-loader/lib/addStylesClient.js */ "./node_modules/vue-style-loader/lib/addStylesClient.js")["default"])
var update = add("1fbb88c0", content, false, {});
// Hot Module Replacement
if(false) {}

/***/ })

}]);
//# sourceMappingURL=src_main_webapp_app_entities_application_application-details_vue.js.map