"use strict";
(self["webpackChunkea_design_it"] = self["webpackChunkea_design_it"] || []).push([["src_main_webapp_app_entities_flow-group_flow-group-update_vue"],{

/***/ "./node_modules/ts-loader/index.js??clonedRuleSet-1[0].rules[0].use[0]!./src/main/webapp/app/entities/flow-group/flow-group-update.component.ts?vue&type=script&lang=ts&":
/*!*******************************************************************************************************************************************************************************!*\
  !*** ./node_modules/ts-loader/index.js??clonedRuleSet-1[0].rules[0].use[0]!./src/main/webapp/app/entities/flow-group/flow-group-update.component.ts?vue&type=script&lang=ts& ***!
  \*******************************************************************************************************************************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony import */ var vue_property_decorator__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! vue-property-decorator */ "./node_modules/vue-property-decorator/lib/index.js");
/* harmony import */ var vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! vuelidate/lib/validators */ "./node_modules/vuelidate/lib/validators/index.js");
/* harmony import */ var _shared_model_flow_group_model__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @/shared/model/flow-group.model */ "./src/main/webapp/app/shared/model/flow-group.model.ts");
var __extends = (undefined && undefined.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        if (typeof b !== "function" && b !== null)
            throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};



var validations = {
    flowGroup: {
        title: {
            maxLength: (0,vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_2__.maxLength)(100),
        },
        url: {
            maxLength: (0,vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_2__.maxLength)(500),
        },
        flow: {
            required: vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_2__.required,
        },
        steps: {
            required: vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_2__.required,
        },
    },
};
var FlowGroupUpdate = /** @class */ (function (_super) {
    __extends(FlowGroupUpdate, _super);
    function FlowGroupUpdate() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.flowGroup = new _shared_model_flow_group_model__WEBPACK_IMPORTED_MODULE_1__.FlowGroup();
        _this.functionalFlows = [];
        _this.functionalFlowSteps = [];
        _this.isSaving = false;
        _this.currentLanguage = '';
        return _this;
    }
    FlowGroupUpdate.prototype.beforeRouteEnter = function (to, from, next) {
        next(function (vm) {
            if (to.params.flowGroupId) {
                vm.retrieveFlowGroup(to.params.flowGroupId);
            }
            vm.initRelationships();
        });
    };
    FlowGroupUpdate.prototype.created = function () {
        var _this = this;
        this.currentLanguage = this.$store.getters.currentLanguage;
        this.$store.watch(function () { return _this.$store.getters.currentLanguage; }, function () {
            _this.currentLanguage = _this.$store.getters.currentLanguage;
        });
    };
    FlowGroupUpdate.prototype.save = function () {
        var _this = this;
        this.isSaving = true;
        if (this.flowGroup.id) {
            this.flowGroupService()
                .update(this.flowGroup)
                .then(function (param) {
                _this.isSaving = false;
                _this.$router.go(-1);
                var message = 'A FlowGroup is updated with identifier ' + param.id;
                return _this.$root.$bvToast.toast(message.toString(), {
                    toaster: 'b-toaster-top-center',
                    title: 'Info',
                    variant: 'info',
                    solid: true,
                    autoHideDelay: 5000,
                });
            })
                .catch(function (error) {
                _this.isSaving = false;
                _this.alertService().showHttpError(_this, error.response);
            });
        }
        else {
            this.flowGroupService()
                .create(this.flowGroup)
                .then(function (param) {
                _this.isSaving = false;
                _this.$router.go(-1);
                var message = 'A FlowGroup is created with identifier ' + param.id;
                _this.$root.$bvToast.toast(message.toString(), {
                    toaster: 'b-toaster-top-center',
                    title: 'Success',
                    variant: 'success',
                    solid: true,
                    autoHideDelay: 5000,
                });
            })
                .catch(function (error) {
                _this.isSaving = false;
                _this.alertService().showHttpError(_this, error.response);
            });
        }
    };
    FlowGroupUpdate.prototype.retrieveFlowGroup = function (flowGroupId) {
        var _this = this;
        this.flowGroupService()
            .find(flowGroupId)
            .then(function (res) {
            _this.flowGroup = res;
        })
            .catch(function (error) {
            _this.alertService().showHttpError(_this, error.response);
        });
    };
    FlowGroupUpdate.prototype.previousState = function () {
        this.$router.go(-1);
    };
    FlowGroupUpdate.prototype.initRelationships = function () {
        var _this = this;
        this.functionalFlowService()
            .retrieve()
            .then(function (res) {
            _this.functionalFlows = res.data;
        });
        this.functionalFlowStepService()
            .retrieve()
            .then(function (res) {
            _this.functionalFlowSteps = res.data;
        });
    };
    __decorate([
        (0,vue_property_decorator__WEBPACK_IMPORTED_MODULE_0__.Inject)('flowGroupService'),
        __metadata("design:type", Function)
    ], FlowGroupUpdate.prototype, "flowGroupService", void 0);
    __decorate([
        (0,vue_property_decorator__WEBPACK_IMPORTED_MODULE_0__.Inject)('alertService'),
        __metadata("design:type", Function)
    ], FlowGroupUpdate.prototype, "alertService", void 0);
    __decorate([
        (0,vue_property_decorator__WEBPACK_IMPORTED_MODULE_0__.Inject)('functionalFlowService'),
        __metadata("design:type", Function)
    ], FlowGroupUpdate.prototype, "functionalFlowService", void 0);
    __decorate([
        (0,vue_property_decorator__WEBPACK_IMPORTED_MODULE_0__.Inject)('functionalFlowStepService'),
        __metadata("design:type", Function)
    ], FlowGroupUpdate.prototype, "functionalFlowStepService", void 0);
    FlowGroupUpdate = __decorate([
        (0,vue_property_decorator__WEBPACK_IMPORTED_MODULE_0__.Component)({
            validations: validations,
        })
    ], FlowGroupUpdate);
    return FlowGroupUpdate;
}(vue_property_decorator__WEBPACK_IMPORTED_MODULE_0__.Vue));
/* harmony default export */ __webpack_exports__["default"] = (FlowGroupUpdate);


/***/ }),

/***/ "./src/main/webapp/app/shared/model/flow-group.model.ts":
/*!**************************************************************!*\
  !*** ./src/main/webapp/app/shared/model/flow-group.model.ts ***!
  \**************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "FlowGroup": function() { return /* binding */ FlowGroup; }
/* harmony export */ });
var FlowGroup = /** @class */ (function () {
    function FlowGroup(id, title, url, flow, steps) {
        this.id = id;
        this.title = title;
        this.url = url;
        this.flow = flow;
        this.steps = steps;
    }
    return FlowGroup;
}());



/***/ }),

/***/ "./src/main/webapp/app/entities/flow-group/flow-group-update.vue":
/*!***********************************************************************!*\
  !*** ./src/main/webapp/app/entities/flow-group/flow-group-update.vue ***!
  \***********************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _flow_group_update_vue_vue_type_template_id_7dc35dd2___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./flow-group-update.vue?vue&type=template&id=7dc35dd2& */ "./src/main/webapp/app/entities/flow-group/flow-group-update.vue?vue&type=template&id=7dc35dd2&");
/* harmony import */ var _flow_group_update_component_ts_vue_type_script_lang_ts___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./flow-group-update.component.ts?vue&type=script&lang=ts& */ "./src/main/webapp/app/entities/flow-group/flow-group-update.component.ts?vue&type=script&lang=ts&");
/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! !../../../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */
;
var component = (0,_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _flow_group_update_component_ts_vue_type_script_lang_ts___WEBPACK_IMPORTED_MODULE_1__["default"],
  _flow_group_update_vue_vue_type_template_id_7dc35dd2___WEBPACK_IMPORTED_MODULE_0__.render,
  _flow_group_update_vue_vue_type_template_id_7dc35dd2___WEBPACK_IMPORTED_MODULE_0__.staticRenderFns,
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "src/main/webapp/app/entities/flow-group/flow-group-update.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./src/main/webapp/app/entities/flow-group/flow-group-update.component.ts?vue&type=script&lang=ts&":
/*!*********************************************************************************************************!*\
  !*** ./src/main/webapp/app/entities/flow-group/flow-group-update.component.ts?vue&type=script&lang=ts& ***!
  \*********************************************************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_ts_loader_index_js_clonedRuleSet_1_0_rules_0_use_0_flow_group_update_component_ts_vue_type_script_lang_ts___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../../node_modules/ts-loader/index.js??clonedRuleSet-1[0].rules[0].use[0]!./flow-group-update.component.ts?vue&type=script&lang=ts& */ "./node_modules/ts-loader/index.js??clonedRuleSet-1[0].rules[0].use[0]!./src/main/webapp/app/entities/flow-group/flow-group-update.component.ts?vue&type=script&lang=ts&");
 /* harmony default export */ __webpack_exports__["default"] = (_node_modules_ts_loader_index_js_clonedRuleSet_1_0_rules_0_use_0_flow_group_update_component_ts_vue_type_script_lang_ts___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./src/main/webapp/app/entities/flow-group/flow-group-update.vue?vue&type=template&id=7dc35dd2&":
/*!******************************************************************************************************!*\
  !*** ./src/main/webapp/app/entities/flow-group/flow-group-update.vue?vue&type=template&id=7dc35dd2& ***!
  \******************************************************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": function() { return /* reexport safe */ _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_flow_group_update_vue_vue_type_template_id_7dc35dd2___WEBPACK_IMPORTED_MODULE_0__.render; },
/* harmony export */   "staticRenderFns": function() { return /* reexport safe */ _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_flow_group_update_vue_vue_type_template_id_7dc35dd2___WEBPACK_IMPORTED_MODULE_0__.staticRenderFns; }
/* harmony export */ });
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_flow_group_update_vue_vue_type_template_id_7dc35dd2___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./flow-group-update.vue?vue&type=template&id=7dc35dd2& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./src/main/webapp/app/entities/flow-group/flow-group-update.vue?vue&type=template&id=7dc35dd2&");


/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./src/main/webapp/app/entities/flow-group/flow-group-update.vue?vue&type=template&id=7dc35dd2&":
/*!*********************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./src/main/webapp/app/entities/flow-group/flow-group-update.vue?vue&type=template&id=7dc35dd2& ***!
  \*********************************************************************************************************************************************************************************************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": function() { return /* binding */ render; },
/* harmony export */   "staticRenderFns": function() { return /* binding */ staticRenderFns; }
/* harmony export */ });
var render = function () {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c("div", { staticClass: "row justify-content-center" }, [
    _c("div", { staticClass: "col-8" }, [
      _c(
        "form",
        {
          attrs: { name: "editForm", role: "form", novalidate: "" },
          on: {
            submit: function ($event) {
              $event.preventDefault()
              return _vm.save()
            },
          },
        },
        [
          _c(
            "h2",
            {
              attrs: {
                id: "eaDesignItApp.flowGroup.home.createOrEditLabel",
                "data-cy": "FlowGroupCreateUpdateHeading",
              },
            },
            [_vm._v("Create or edit a FlowGroup")]
          ),
          _vm._v(" "),
          _c("div", [
            _vm.flowGroup.id
              ? _c("div", { staticClass: "form-group" }, [
                  _c("label", { attrs: { for: "id" } }, [_vm._v("ID")]),
                  _vm._v(" "),
                  _c("input", {
                    directives: [
                      {
                        name: "model",
                        rawName: "v-model",
                        value: _vm.flowGroup.id,
                        expression: "flowGroup.id",
                      },
                    ],
                    staticClass: "form-control",
                    attrs: { type: "text", id: "id", name: "id", readonly: "" },
                    domProps: { value: _vm.flowGroup.id },
                    on: {
                      input: function ($event) {
                        if ($event.target.composing) {
                          return
                        }
                        _vm.$set(_vm.flowGroup, "id", $event.target.value)
                      },
                    },
                  }),
                ])
              : _vm._e(),
            _vm._v(" "),
            _c("div", { staticClass: "form-group" }, [
              _c(
                "label",
                {
                  staticClass: "form-control-label",
                  attrs: { for: "flow-group-title" },
                },
                [_vm._v("Title")]
              ),
              _vm._v(" "),
              _c("input", {
                directives: [
                  {
                    name: "model",
                    rawName: "v-model",
                    value: _vm.$v.flowGroup.title.$model,
                    expression: "$v.flowGroup.title.$model",
                  },
                ],
                staticClass: "form-control",
                class: {
                  valid: !_vm.$v.flowGroup.title.$invalid,
                  invalid: _vm.$v.flowGroup.title.$invalid,
                },
                attrs: {
                  type: "text",
                  name: "title",
                  id: "flow-group-title",
                  "data-cy": "title",
                },
                domProps: { value: _vm.$v.flowGroup.title.$model },
                on: {
                  input: function ($event) {
                    if ($event.target.composing) {
                      return
                    }
                    _vm.$set(
                      _vm.$v.flowGroup.title,
                      "$model",
                      $event.target.value
                    )
                  },
                },
              }),
              _vm._v(" "),
              _vm.$v.flowGroup.title.$anyDirty &&
              _vm.$v.flowGroup.title.$invalid
                ? _c("div", [
                    !_vm.$v.flowGroup.title.maxLength
                      ? _c("small", { staticClass: "form-text text-danger" }, [
                          _vm._v(
                            "\n              This field cannot be longer than 100 characters.\n            "
                          ),
                        ])
                      : _vm._e(),
                  ])
                : _vm._e(),
            ]),
            _vm._v(" "),
            _c("div", { staticClass: "form-group" }, [
              _c(
                "label",
                {
                  staticClass: "form-control-label",
                  attrs: { for: "flow-group-url" },
                },
                [_vm._v("Url")]
              ),
              _vm._v(" "),
              _c("input", {
                directives: [
                  {
                    name: "model",
                    rawName: "v-model",
                    value: _vm.$v.flowGroup.url.$model,
                    expression: "$v.flowGroup.url.$model",
                  },
                ],
                staticClass: "form-control",
                class: {
                  valid: !_vm.$v.flowGroup.url.$invalid,
                  invalid: _vm.$v.flowGroup.url.$invalid,
                },
                attrs: {
                  type: "text",
                  name: "url",
                  id: "flow-group-url",
                  "data-cy": "url",
                },
                domProps: { value: _vm.$v.flowGroup.url.$model },
                on: {
                  input: function ($event) {
                    if ($event.target.composing) {
                      return
                    }
                    _vm.$set(
                      _vm.$v.flowGroup.url,
                      "$model",
                      $event.target.value
                    )
                  },
                },
              }),
              _vm._v(" "),
              _vm.$v.flowGroup.url.$anyDirty && _vm.$v.flowGroup.url.$invalid
                ? _c("div", [
                    !_vm.$v.flowGroup.url.maxLength
                      ? _c("small", { staticClass: "form-text text-danger" }, [
                          _vm._v(
                            "\n              This field cannot be longer than 500 characters.\n            "
                          ),
                        ])
                      : _vm._e(),
                  ])
                : _vm._e(),
            ]),
            _vm._v(" "),
            _c("div", { staticClass: "form-group" }, [
              _c(
                "label",
                {
                  staticClass: "form-control-label",
                  attrs: { for: "flow-group-flow" },
                },
                [_vm._v("Flow")]
              ),
              _vm._v(" "),
              _c(
                "select",
                {
                  directives: [
                    {
                      name: "model",
                      rawName: "v-model",
                      value: _vm.flowGroup.flow,
                      expression: "flowGroup.flow",
                    },
                  ],
                  staticClass: "form-control",
                  attrs: {
                    id: "flow-group-flow",
                    "data-cy": "flow",
                    name: "flow",
                    required: "",
                  },
                  on: {
                    change: function ($event) {
                      var $$selectedVal = Array.prototype.filter
                        .call($event.target.options, function (o) {
                          return o.selected
                        })
                        .map(function (o) {
                          var val = "_value" in o ? o._value : o.value
                          return val
                        })
                      _vm.$set(
                        _vm.flowGroup,
                        "flow",
                        $event.target.multiple
                          ? $$selectedVal
                          : $$selectedVal[0]
                      )
                    },
                  },
                },
                [
                  !_vm.flowGroup.flow
                    ? _c("option", {
                        attrs: { selected: "" },
                        domProps: { value: null },
                      })
                    : _vm._e(),
                  _vm._v(" "),
                  _vm._l(_vm.functionalFlows, function (functionalFlowOption) {
                    return _c(
                      "option",
                      {
                        key: functionalFlowOption.id,
                        domProps: {
                          value:
                            _vm.flowGroup.flow &&
                            functionalFlowOption.id === _vm.flowGroup.flow.id
                              ? _vm.flowGroup.flow
                              : functionalFlowOption,
                        },
                      },
                      [
                        _vm._v(
                          "\n              " +
                            _vm._s(functionalFlowOption.alias) +
                            "\n            "
                        ),
                      ]
                    )
                  }),
                ],
                2
              ),
            ]),
            _vm._v(" "),
            _vm.$v.flowGroup.flow.$anyDirty && _vm.$v.flowGroup.flow.$invalid
              ? _c("div", [
                  !_vm.$v.flowGroup.flow.required
                    ? _c("small", { staticClass: "form-text text-danger" }, [
                        _vm._v(" This field is required. "),
                      ])
                    : _vm._e(),
                ])
              : _vm._e(),
            _vm._v(" "),
            _vm.$v.flowGroup.steps.$anyDirty && _vm.$v.flowGroup.steps.$invalid
              ? _c("div", [
                  !_vm.$v.flowGroup.steps.required
                    ? _c("small", { staticClass: "form-text text-danger" }, [
                        _vm._v(" This field is required. "),
                      ])
                    : _vm._e(),
                ])
              : _vm._e(),
          ]),
          _vm._v(" "),
          _c("div", [
            _c(
              "button",
              {
                staticClass: "btn btn-secondary",
                attrs: {
                  type: "button",
                  id: "cancel-save",
                  "data-cy": "entityCreateCancelButton",
                },
                on: {
                  click: function ($event) {
                    return _vm.previousState()
                  },
                },
              },
              [
                _c("font-awesome-icon", { attrs: { icon: "ban" } }),
                _vm._v(" "),
                _c("span", [_vm._v("Cancel")]),
              ],
              1
            ),
            _vm._v(" "),
            _c(
              "button",
              {
                staticClass: "btn btn-primary",
                attrs: {
                  type: "submit",
                  id: "save-entity",
                  "data-cy": "entityCreateSaveButton",
                  disabled: _vm.$v.flowGroup.$invalid || _vm.isSaving,
                },
              },
              [
                _c("font-awesome-icon", { attrs: { icon: "save" } }),
                _vm._v(" "),
                _c("span", [_vm._v("Save")]),
              ],
              1
            ),
          ]),
        ]
      ),
    ]),
  ])
}
var staticRenderFns = []
render._withStripped = true



/***/ })

}]);
//# sourceMappingURL=src_main_webapp_app_entities_flow-group_flow-group-update_vue.js.map