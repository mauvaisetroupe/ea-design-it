"use strict";
(self["webpackChunkea_design_it"] = self["webpackChunkea_design_it"] || []).push([["src_main_webapp_app_entities_data-flow_data-flow-update_vue"],{

/***/ "./node_modules/ts-loader/index.js??clonedRuleSet-1[0].rules[0].use[0]!./src/main/webapp/app/entities/data-flow/data-flow-update.component.ts?vue&type=script&lang=ts&":
/*!*****************************************************************************************************************************************************************************!*\
  !*** ./node_modules/ts-loader/index.js??clonedRuleSet-1[0].rules[0].use[0]!./src/main/webapp/app/entities/data-flow/data-flow-update.component.ts?vue&type=script&lang=ts& ***!
  \*****************************************************************************************************************************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony import */ var vue_property_decorator__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! vue-property-decorator */ "./node_modules/vue-property-decorator/lib/index.js");
/* harmony import */ var vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! vuelidate/lib/validators */ "./node_modules/vuelidate/lib/validators/index.js");
/* harmony import */ var _shared_model_data_flow_model__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @/shared/model/data-flow.model */ "./src/main/webapp/app/shared/model/data-flow.model.ts");
/* harmony import */ var _shared_model_enumerations_frequency_model__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @/shared/model/enumerations/frequency.model */ "./src/main/webapp/app/shared/model/enumerations/frequency.model.ts");
var __extends = (undefined && undefined.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        if (typeof b !== "function" && b !== null)
            throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};




var validations = {
    dataFlow: {
        resourceName: {
            required: vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_3__.required,
        },
        resourceType: {},
        description: {
            maxLength: (0,vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_3__.maxLength)(1000),
        },
        frequency: {},
        contractURL: {
            maxLength: (0,vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_3__.maxLength)(500),
        },
        documentationURL: {
            maxLength: (0,vuelidate_lib_validators__WEBPACK_IMPORTED_MODULE_3__.maxLength)(500),
        },
        startDate: {},
        endDate: {},
    },
};
var DataFlowUpdate = /** @class */ (function (_super) {
    __extends(DataFlowUpdate, _super);
    function DataFlowUpdate() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.dataFlow = new _shared_model_data_flow_model__WEBPACK_IMPORTED_MODULE_1__.DataFlow();
        _this.dataFlowItems = [];
        _this.dataFormats = [];
        _this.functionalFlows = [];
        _this.flowInterfaces = [];
        _this.frequencyValues = Object.keys(_shared_model_enumerations_frequency_model__WEBPACK_IMPORTED_MODULE_2__.Frequency);
        _this.isSaving = false;
        _this.currentLanguage = '';
        return _this;
    }
    DataFlowUpdate.prototype.beforeRouteEnter = function (to, from, next) {
        next(function (vm) {
            if (to.params.dataFlowId) {
                vm.retrieveDataFlow(to.params.dataFlowId);
            }
            vm.initRelationships();
        });
    };
    DataFlowUpdate.prototype.created = function () {
        var _this = this;
        this.currentLanguage = this.$store.getters.currentLanguage;
        this.$store.watch(function () { return _this.$store.getters.currentLanguage; }, function () {
            _this.currentLanguage = _this.$store.getters.currentLanguage;
        });
        this.dataFlow.functionalFlows = [];
    };
    DataFlowUpdate.prototype.save = function () {
        var _this = this;
        this.isSaving = true;
        if (this.dataFlow.id) {
            this.dataFlowService()
                .update(this.dataFlow)
                .then(function (param) {
                _this.isSaving = false;
                _this.$router.go(-1);
                var message = 'A DataFlow is updated with identifier ' + param.id;
                return _this.$root.$bvToast.toast(message.toString(), {
                    toaster: 'b-toaster-top-center',
                    title: 'Info',
                    variant: 'info',
                    solid: true,
                    autoHideDelay: 5000,
                });
            })
                .catch(function (error) {
                _this.isSaving = false;
                _this.alertService().showHttpError(_this, error.response);
            });
        }
        else {
            this.dataFlowService()
                .create(this.dataFlow)
                .then(function (param) {
                _this.isSaving = false;
                _this.$router.go(-1);
                var message = 'A DataFlow is created with identifier ' + param.id;
                _this.$root.$bvToast.toast(message.toString(), {
                    toaster: 'b-toaster-top-center',
                    title: 'Success',
                    variant: 'success',
                    solid: true,
                    autoHideDelay: 5000,
                });
            })
                .catch(function (error) {
                _this.isSaving = false;
                _this.alertService().showHttpError(_this, error.response);
            });
        }
    };
    DataFlowUpdate.prototype.retrieveDataFlow = function (dataFlowId) {
        var _this = this;
        this.dataFlowService()
            .find(dataFlowId)
            .then(function (res) {
            _this.dataFlow = res;
        })
            .catch(function (error) {
            _this.alertService().showHttpError(_this, error.response);
        });
    };
    DataFlowUpdate.prototype.previousState = function () {
        this.$router.go(-1);
    };
    DataFlowUpdate.prototype.initRelationships = function () {
        var _this = this;
        this.dataFlowItemService()
            .retrieve()
            .then(function (res) {
            _this.dataFlowItems = res.data;
        });
        this.dataFormatService()
            .retrieve()
            .then(function (res) {
            _this.dataFormats = res.data;
        });
        this.functionalFlowService()
            .retrieve()
            .then(function (res) {
            _this.functionalFlows = res.data;
        });
        this.flowInterfaceService()
            .retrieve()
            .then(function (res) {
            _this.flowInterfaces = res.data;
        });
    };
    DataFlowUpdate.prototype.getSelected = function (selectedVals, option) {
        var _a;
        if (selectedVals) {
            return (_a = selectedVals.find(function (value) { return option.id === value.id; })) !== null && _a !== void 0 ? _a : option;
        }
        return option;
    };
    __decorate([
        (0,vue_property_decorator__WEBPACK_IMPORTED_MODULE_0__.Inject)('dataFlowService'),
        __metadata("design:type", Function)
    ], DataFlowUpdate.prototype, "dataFlowService", void 0);
    __decorate([
        (0,vue_property_decorator__WEBPACK_IMPORTED_MODULE_0__.Inject)('alertService'),
        __metadata("design:type", Function)
    ], DataFlowUpdate.prototype, "alertService", void 0);
    __decorate([
        (0,vue_property_decorator__WEBPACK_IMPORTED_MODULE_0__.Inject)('dataFlowItemService'),
        __metadata("design:type", Function)
    ], DataFlowUpdate.prototype, "dataFlowItemService", void 0);
    __decorate([
        (0,vue_property_decorator__WEBPACK_IMPORTED_MODULE_0__.Inject)('dataFormatService'),
        __metadata("design:type", Function)
    ], DataFlowUpdate.prototype, "dataFormatService", void 0);
    __decorate([
        (0,vue_property_decorator__WEBPACK_IMPORTED_MODULE_0__.Inject)('functionalFlowService'),
        __metadata("design:type", Function)
    ], DataFlowUpdate.prototype, "functionalFlowService", void 0);
    __decorate([
        (0,vue_property_decorator__WEBPACK_IMPORTED_MODULE_0__.Inject)('flowInterfaceService'),
        __metadata("design:type", Function)
    ], DataFlowUpdate.prototype, "flowInterfaceService", void 0);
    DataFlowUpdate = __decorate([
        (0,vue_property_decorator__WEBPACK_IMPORTED_MODULE_0__.Component)({
            validations: validations,
        })
    ], DataFlowUpdate);
    return DataFlowUpdate;
}(vue_property_decorator__WEBPACK_IMPORTED_MODULE_0__.Vue));
/* harmony default export */ __webpack_exports__["default"] = (DataFlowUpdate);


/***/ }),

/***/ "./src/main/webapp/app/shared/model/data-flow.model.ts":
/*!*************************************************************!*\
  !*** ./src/main/webapp/app/shared/model/data-flow.model.ts ***!
  \*************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "DataFlow": function() { return /* binding */ DataFlow; }
/* harmony export */ });
var DataFlow = /** @class */ (function () {
    function DataFlow(id, resourceName, resourceType, description, frequency, contractURL, documentationURL, startDate, endDate, items, format, functionalFlows, flowInterface) {
        this.id = id;
        this.resourceName = resourceName;
        this.resourceType = resourceType;
        this.description = description;
        this.frequency = frequency;
        this.contractURL = contractURL;
        this.documentationURL = documentationURL;
        this.startDate = startDate;
        this.endDate = endDate;
        this.items = items;
        this.format = format;
        this.functionalFlows = functionalFlows;
        this.flowInterface = flowInterface;
    }
    return DataFlow;
}());



/***/ }),

/***/ "./src/main/webapp/app/shared/model/enumerations/frequency.model.ts":
/*!**************************************************************************!*\
  !*** ./src/main/webapp/app/shared/model/enumerations/frequency.model.ts ***!
  \**************************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Frequency": function() { return /* binding */ Frequency; }
/* harmony export */ });
var Frequency;
(function (Frequency) {
    Frequency["HOURLY"] = "HOURLY";
    Frequency["DAILY"] = "DAILY";
    Frequency["WEEKLY"] = "WEEKLY";
    Frequency["MONTHLY"] = "MONTHLY";
    Frequency["YEARLY"] = "YEARLY";
    Frequency["ON_DEMAND"] = "ON_DEMAND";
    Frequency["NRT"] = "NRT";
    Frequency["ON_USER_ACTION"] = "ON_USER_ACTION";
    Frequency["INTRADAY"] = "INTRADAY";
})(Frequency || (Frequency = {}));


/***/ }),

/***/ "./src/main/webapp/app/entities/data-flow/data-flow-update.vue":
/*!*********************************************************************!*\
  !*** ./src/main/webapp/app/entities/data-flow/data-flow-update.vue ***!
  \*********************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _data_flow_update_vue_vue_type_template_id_bb8bd1a4___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./data-flow-update.vue?vue&type=template&id=bb8bd1a4& */ "./src/main/webapp/app/entities/data-flow/data-flow-update.vue?vue&type=template&id=bb8bd1a4&");
/* harmony import */ var _data_flow_update_component_ts_vue_type_script_lang_ts___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./data-flow-update.component.ts?vue&type=script&lang=ts& */ "./src/main/webapp/app/entities/data-flow/data-flow-update.component.ts?vue&type=script&lang=ts&");
/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! !../../../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */
;
var component = (0,_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _data_flow_update_component_ts_vue_type_script_lang_ts___WEBPACK_IMPORTED_MODULE_1__["default"],
  _data_flow_update_vue_vue_type_template_id_bb8bd1a4___WEBPACK_IMPORTED_MODULE_0__.render,
  _data_flow_update_vue_vue_type_template_id_bb8bd1a4___WEBPACK_IMPORTED_MODULE_0__.staticRenderFns,
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "src/main/webapp/app/entities/data-flow/data-flow-update.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./src/main/webapp/app/entities/data-flow/data-flow-update.component.ts?vue&type=script&lang=ts&":
/*!*******************************************************************************************************!*\
  !*** ./src/main/webapp/app/entities/data-flow/data-flow-update.component.ts?vue&type=script&lang=ts& ***!
  \*******************************************************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_ts_loader_index_js_clonedRuleSet_1_0_rules_0_use_0_data_flow_update_component_ts_vue_type_script_lang_ts___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../../node_modules/ts-loader/index.js??clonedRuleSet-1[0].rules[0].use[0]!./data-flow-update.component.ts?vue&type=script&lang=ts& */ "./node_modules/ts-loader/index.js??clonedRuleSet-1[0].rules[0].use[0]!./src/main/webapp/app/entities/data-flow/data-flow-update.component.ts?vue&type=script&lang=ts&");
 /* harmony default export */ __webpack_exports__["default"] = (_node_modules_ts_loader_index_js_clonedRuleSet_1_0_rules_0_use_0_data_flow_update_component_ts_vue_type_script_lang_ts___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./src/main/webapp/app/entities/data-flow/data-flow-update.vue?vue&type=template&id=bb8bd1a4&":
/*!****************************************************************************************************!*\
  !*** ./src/main/webapp/app/entities/data-flow/data-flow-update.vue?vue&type=template&id=bb8bd1a4& ***!
  \****************************************************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": function() { return /* reexport safe */ _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_data_flow_update_vue_vue_type_template_id_bb8bd1a4___WEBPACK_IMPORTED_MODULE_0__.render; },
/* harmony export */   "staticRenderFns": function() { return /* reexport safe */ _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_data_flow_update_vue_vue_type_template_id_bb8bd1a4___WEBPACK_IMPORTED_MODULE_0__.staticRenderFns; }
/* harmony export */ });
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_data_flow_update_vue_vue_type_template_id_bb8bd1a4___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./data-flow-update.vue?vue&type=template&id=bb8bd1a4& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./src/main/webapp/app/entities/data-flow/data-flow-update.vue?vue&type=template&id=bb8bd1a4&");


/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./src/main/webapp/app/entities/data-flow/data-flow-update.vue?vue&type=template&id=bb8bd1a4&":
/*!*******************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./src/main/webapp/app/entities/data-flow/data-flow-update.vue?vue&type=template&id=bb8bd1a4& ***!
  \*******************************************************************************************************************************************************************************************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": function() { return /* binding */ render; },
/* harmony export */   "staticRenderFns": function() { return /* binding */ staticRenderFns; }
/* harmony export */ });
var render = function () {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c("div", { staticClass: "row justify-content-center" }, [
    _c("div", { staticClass: "col-8" }, [
      _c(
        "form",
        {
          attrs: { name: "editForm", role: "form", novalidate: "" },
          on: {
            submit: function ($event) {
              $event.preventDefault()
              return _vm.save()
            },
          },
        },
        [
          _c(
            "h2",
            {
              attrs: {
                id: "eaDesignItApp.dataFlow.home.createOrEditLabel",
                "data-cy": "DataFlowCreateUpdateHeading",
              },
            },
            [
              _c("font-awesome-icon", {
                staticStyle: { color: "Tomato", "font-size": "0.9em" },
                attrs: { icon: "folder" },
              }),
              _vm._v(" Create or edit a DataFlow\n      "),
            ],
            1
          ),
          _vm._v(" "),
          _c("div", [
            _vm.dataFlow.id
              ? _c("div", { staticClass: "form-group" }, [
                  _c("label", { attrs: { for: "id" } }, [_vm._v("ID")]),
                  _vm._v(" "),
                  _c("input", {
                    directives: [
                      {
                        name: "model",
                        rawName: "v-model",
                        value: _vm.dataFlow.id,
                        expression: "dataFlow.id",
                      },
                    ],
                    staticClass: "form-control",
                    attrs: { type: "text", id: "id", name: "id", readonly: "" },
                    domProps: { value: _vm.dataFlow.id },
                    on: {
                      input: function ($event) {
                        if ($event.target.composing) {
                          return
                        }
                        _vm.$set(_vm.dataFlow, "id", $event.target.value)
                      },
                    },
                  }),
                ])
              : _vm._e(),
            _vm._v(" "),
            _c("div", { staticClass: "form-group" }, [
              _c(
                "label",
                {
                  staticClass: "form-control-label",
                  attrs: { for: "data-flow-resourceName" },
                },
                [_vm._v("Resource Name")]
              ),
              _vm._v(" "),
              _c("input", {
                directives: [
                  {
                    name: "model",
                    rawName: "v-model",
                    value: _vm.$v.dataFlow.resourceName.$model,
                    expression: "$v.dataFlow.resourceName.$model",
                  },
                ],
                staticClass: "form-control",
                class: {
                  valid: !_vm.$v.dataFlow.resourceName.$invalid,
                  invalid: _vm.$v.dataFlow.resourceName.$invalid,
                },
                attrs: {
                  type: "text",
                  name: "resourceName",
                  id: "data-flow-resourceName",
                  "data-cy": "resourceName",
                  required: "",
                },
                domProps: { value: _vm.$v.dataFlow.resourceName.$model },
                on: {
                  input: function ($event) {
                    if ($event.target.composing) {
                      return
                    }
                    _vm.$set(
                      _vm.$v.dataFlow.resourceName,
                      "$model",
                      $event.target.value
                    )
                  },
                },
              }),
              _vm._v(" "),
              _vm.$v.dataFlow.resourceName.$anyDirty &&
              _vm.$v.dataFlow.resourceName.$invalid
                ? _c("div", [
                    !_vm.$v.dataFlow.resourceName.required
                      ? _c("small", { staticClass: "form-text text-danger" }, [
                          _vm._v(" This field is required. "),
                        ])
                      : _vm._e(),
                  ])
                : _vm._e(),
            ]),
            _vm._v(" "),
            _c("div", { staticClass: "form-group" }, [
              _c(
                "label",
                {
                  staticClass: "form-control-label",
                  attrs: { for: "data-flow-resourceType" },
                },
                [_vm._v("Resource Type")]
              ),
              _vm._v(" "),
              _c("input", {
                directives: [
                  {
                    name: "model",
                    rawName: "v-model",
                    value: _vm.$v.dataFlow.resourceType.$model,
                    expression: "$v.dataFlow.resourceType.$model",
                  },
                ],
                staticClass: "form-control",
                class: {
                  valid: !_vm.$v.dataFlow.resourceType.$invalid,
                  invalid: _vm.$v.dataFlow.resourceType.$invalid,
                },
                attrs: {
                  type: "text",
                  name: "resourceType",
                  id: "data-flow-resourceType",
                  "data-cy": "resourceType",
                },
                domProps: { value: _vm.$v.dataFlow.resourceType.$model },
                on: {
                  input: function ($event) {
                    if ($event.target.composing) {
                      return
                    }
                    _vm.$set(
                      _vm.$v.dataFlow.resourceType,
                      "$model",
                      $event.target.value
                    )
                  },
                },
              }),
            ]),
            _vm._v(" "),
            _c("div", { staticClass: "form-group" }, [
              _c(
                "label",
                {
                  staticClass: "form-control-label",
                  attrs: { for: "data-flow-description" },
                },
                [_vm._v("Description")]
              ),
              _vm._v(" "),
              _c("input", {
                directives: [
                  {
                    name: "model",
                    rawName: "v-model",
                    value: _vm.$v.dataFlow.description.$model,
                    expression: "$v.dataFlow.description.$model",
                  },
                ],
                staticClass: "form-control",
                class: {
                  valid: !_vm.$v.dataFlow.description.$invalid,
                  invalid: _vm.$v.dataFlow.description.$invalid,
                },
                attrs: {
                  type: "text",
                  name: "description",
                  id: "data-flow-description",
                  "data-cy": "description",
                },
                domProps: { value: _vm.$v.dataFlow.description.$model },
                on: {
                  input: function ($event) {
                    if ($event.target.composing) {
                      return
                    }
                    _vm.$set(
                      _vm.$v.dataFlow.description,
                      "$model",
                      $event.target.value
                    )
                  },
                },
              }),
              _vm._v(" "),
              _vm.$v.dataFlow.description.$anyDirty &&
              _vm.$v.dataFlow.description.$invalid
                ? _c("div", [
                    !_vm.$v.dataFlow.description.maxLength
                      ? _c("small", { staticClass: "form-text text-danger" }, [
                          _vm._v(
                            "\n              This field cannot be longer than 1000 characters.\n            "
                          ),
                        ])
                      : _vm._e(),
                  ])
                : _vm._e(),
            ]),
            _vm._v(" "),
            _c("div", { staticClass: "form-group" }, [
              _c(
                "label",
                {
                  staticClass: "form-control-label",
                  attrs: { for: "data-flow-frequency" },
                },
                [_vm._v("Frequency")]
              ),
              _vm._v(" "),
              _c(
                "select",
                {
                  directives: [
                    {
                      name: "model",
                      rawName: "v-model",
                      value: _vm.$v.dataFlow.frequency.$model,
                      expression: "$v.dataFlow.frequency.$model",
                    },
                  ],
                  staticClass: "form-control",
                  class: {
                    valid: !_vm.$v.dataFlow.frequency.$invalid,
                    invalid: _vm.$v.dataFlow.frequency.$invalid,
                  },
                  attrs: {
                    name: "frequency",
                    id: "data-flow-frequency",
                    "data-cy": "frequency",
                  },
                  on: {
                    change: function ($event) {
                      var $$selectedVal = Array.prototype.filter
                        .call($event.target.options, function (o) {
                          return o.selected
                        })
                        .map(function (o) {
                          var val = "_value" in o ? o._value : o.value
                          return val
                        })
                      _vm.$set(
                        _vm.$v.dataFlow.frequency,
                        "$model",
                        $event.target.multiple
                          ? $$selectedVal
                          : $$selectedVal[0]
                      )
                    },
                  },
                },
                _vm._l(_vm.frequencyValues, function (frequency) {
                  return _c(
                    "option",
                    { key: frequency, domProps: { value: frequency } },
                    [_vm._v(_vm._s(frequency))]
                  )
                }),
                0
              ),
            ]),
            _vm._v(" "),
            _c("div", { staticClass: "form-group" }, [
              _c(
                "label",
                {
                  staticClass: "form-control-label",
                  attrs: { for: "data-flow-contractURL" },
                },
                [_vm._v("Contract URL")]
              ),
              _vm._v(" "),
              _c("input", {
                directives: [
                  {
                    name: "model",
                    rawName: "v-model",
                    value: _vm.$v.dataFlow.contractURL.$model,
                    expression: "$v.dataFlow.contractURL.$model",
                  },
                ],
                staticClass: "form-control",
                class: {
                  valid: !_vm.$v.dataFlow.contractURL.$invalid,
                  invalid: _vm.$v.dataFlow.contractURL.$invalid,
                },
                attrs: {
                  type: "text",
                  name: "contractURL",
                  id: "data-flow-contractURL",
                  "data-cy": "contractURL",
                },
                domProps: { value: _vm.$v.dataFlow.contractURL.$model },
                on: {
                  input: function ($event) {
                    if ($event.target.composing) {
                      return
                    }
                    _vm.$set(
                      _vm.$v.dataFlow.contractURL,
                      "$model",
                      $event.target.value
                    )
                  },
                },
              }),
              _vm._v(" "),
              _vm.$v.dataFlow.contractURL.$anyDirty &&
              _vm.$v.dataFlow.contractURL.$invalid
                ? _c("div", [
                    !_vm.$v.dataFlow.contractURL.maxLength
                      ? _c("small", { staticClass: "form-text text-danger" }, [
                          _vm._v(
                            "\n              This field cannot be longer than 500 characters.\n            "
                          ),
                        ])
                      : _vm._e(),
                  ])
                : _vm._e(),
            ]),
            _vm._v(" "),
            _c("div", { staticClass: "form-group" }, [
              _c(
                "label",
                {
                  staticClass: "form-control-label",
                  attrs: { for: "data-flow-documentationURL" },
                },
                [_vm._v("Documentation URL")]
              ),
              _vm._v(" "),
              _c("input", {
                directives: [
                  {
                    name: "model",
                    rawName: "v-model",
                    value: _vm.$v.dataFlow.documentationURL.$model,
                    expression: "$v.dataFlow.documentationURL.$model",
                  },
                ],
                staticClass: "form-control",
                class: {
                  valid: !_vm.$v.dataFlow.documentationURL.$invalid,
                  invalid: _vm.$v.dataFlow.documentationURL.$invalid,
                },
                attrs: {
                  type: "text",
                  name: "documentationURL",
                  id: "data-flow-documentationURL",
                  "data-cy": "documentationURL",
                },
                domProps: { value: _vm.$v.dataFlow.documentationURL.$model },
                on: {
                  input: function ($event) {
                    if ($event.target.composing) {
                      return
                    }
                    _vm.$set(
                      _vm.$v.dataFlow.documentationURL,
                      "$model",
                      $event.target.value
                    )
                  },
                },
              }),
              _vm._v(" "),
              _vm.$v.dataFlow.documentationURL.$anyDirty &&
              _vm.$v.dataFlow.documentationURL.$invalid
                ? _c("div", [
                    !_vm.$v.dataFlow.documentationURL.maxLength
                      ? _c("small", { staticClass: "form-text text-danger" }, [
                          _vm._v(
                            "\n              This field cannot be longer than 500 characters.\n            "
                          ),
                        ])
                      : _vm._e(),
                  ])
                : _vm._e(),
            ]),
            _vm._v(" "),
            _c(
              "div",
              { staticClass: "form-group" },
              [
                _c(
                  "label",
                  {
                    staticClass: "form-control-label",
                    attrs: { for: "data-flow-startDate" },
                  },
                  [_vm._v("Start Date")]
                ),
                _vm._v(" "),
                _c(
                  "b-input-group",
                  { staticClass: "mb-3" },
                  [
                    _c(
                      "b-input-group-prepend",
                      [
                        _c("b-form-datepicker", {
                          staticClass: "form-control",
                          attrs: {
                            "aria-controls": "data-flow-startDate",
                            name: "startDate",
                            locale: _vm.currentLanguage,
                            "button-only": "",
                            "today-button": "",
                            "reset-button": "",
                            "close-button": "",
                          },
                          model: {
                            value: _vm.$v.dataFlow.startDate.$model,
                            callback: function ($$v) {
                              _vm.$set(_vm.$v.dataFlow.startDate, "$model", $$v)
                            },
                            expression: "$v.dataFlow.startDate.$model",
                          },
                        }),
                      ],
                      1
                    ),
                    _vm._v(" "),
                    _c("b-form-input", {
                      staticClass: "form-control",
                      class: {
                        valid: !_vm.$v.dataFlow.startDate.$invalid,
                        invalid: _vm.$v.dataFlow.startDate.$invalid,
                      },
                      attrs: {
                        id: "data-flow-startDate",
                        "data-cy": "startDate",
                        type: "text",
                        name: "startDate",
                      },
                      model: {
                        value: _vm.$v.dataFlow.startDate.$model,
                        callback: function ($$v) {
                          _vm.$set(_vm.$v.dataFlow.startDate, "$model", $$v)
                        },
                        expression: "$v.dataFlow.startDate.$model",
                      },
                    }),
                  ],
                  1
                ),
              ],
              1
            ),
            _vm._v(" "),
            _c(
              "div",
              { staticClass: "form-group" },
              [
                _c(
                  "label",
                  {
                    staticClass: "form-control-label",
                    attrs: { for: "data-flow-endDate" },
                  },
                  [_vm._v("End Date")]
                ),
                _vm._v(" "),
                _c(
                  "b-input-group",
                  { staticClass: "mb-3" },
                  [
                    _c(
                      "b-input-group-prepend",
                      [
                        _c("b-form-datepicker", {
                          staticClass: "form-control",
                          attrs: {
                            "aria-controls": "data-flow-endDate",
                            name: "endDate",
                            locale: _vm.currentLanguage,
                            "button-only": "",
                            "today-button": "",
                            "reset-button": "",
                            "close-button": "",
                          },
                          model: {
                            value: _vm.$v.dataFlow.endDate.$model,
                            callback: function ($$v) {
                              _vm.$set(_vm.$v.dataFlow.endDate, "$model", $$v)
                            },
                            expression: "$v.dataFlow.endDate.$model",
                          },
                        }),
                      ],
                      1
                    ),
                    _vm._v(" "),
                    _c("b-form-input", {
                      staticClass: "form-control",
                      class: {
                        valid: !_vm.$v.dataFlow.endDate.$invalid,
                        invalid: _vm.$v.dataFlow.endDate.$invalid,
                      },
                      attrs: {
                        id: "data-flow-endDate",
                        "data-cy": "endDate",
                        type: "text",
                        name: "endDate",
                      },
                      model: {
                        value: _vm.$v.dataFlow.endDate.$model,
                        callback: function ($$v) {
                          _vm.$set(_vm.$v.dataFlow.endDate, "$model", $$v)
                        },
                        expression: "$v.dataFlow.endDate.$model",
                      },
                    }),
                  ],
                  1
                ),
              ],
              1
            ),
            _vm._v(" "),
            _c("div", { staticClass: "form-group" }, [
              _c(
                "label",
                {
                  staticClass: "form-control-label",
                  attrs: { for: "data-flow-format" },
                },
                [_vm._v("Format")]
              ),
              _vm._v(" "),
              _c(
                "select",
                {
                  directives: [
                    {
                      name: "model",
                      rawName: "v-model",
                      value: _vm.dataFlow.format,
                      expression: "dataFlow.format",
                    },
                  ],
                  staticClass: "form-control",
                  attrs: {
                    id: "data-flow-format",
                    "data-cy": "format",
                    name: "format",
                  },
                  on: {
                    change: function ($event) {
                      var $$selectedVal = Array.prototype.filter
                        .call($event.target.options, function (o) {
                          return o.selected
                        })
                        .map(function (o) {
                          var val = "_value" in o ? o._value : o.value
                          return val
                        })
                      _vm.$set(
                        _vm.dataFlow,
                        "format",
                        $event.target.multiple
                          ? $$selectedVal
                          : $$selectedVal[0]
                      )
                    },
                  },
                },
                [
                  _c("option", { domProps: { value: null } }),
                  _vm._v(" "),
                  _vm._l(_vm.dataFormats, function (dataFormatOption) {
                    return _c(
                      "option",
                      {
                        key: dataFormatOption.id,
                        domProps: {
                          value:
                            _vm.dataFlow.format &&
                            dataFormatOption.id === _vm.dataFlow.format.id
                              ? _vm.dataFlow.format
                              : dataFormatOption,
                        },
                      },
                      [
                        _vm._v(
                          "\n              " +
                            _vm._s(dataFormatOption.name) +
                            "\n            "
                        ),
                      ]
                    )
                  }),
                ],
                2
              ),
            ]),
            _vm._v(" "),
            _c("div", { staticClass: "form-group" }, [
              _c("label", { attrs: { for: "data-flow-functionalFlows" } }, [
                _vm._v("Functional Flows"),
              ]),
              _vm._v(" "),
              _vm.dataFlow.functionalFlows !== undefined
                ? _c(
                    "select",
                    {
                      directives: [
                        {
                          name: "model",
                          rawName: "v-model",
                          value: _vm.dataFlow.functionalFlows,
                          expression: "dataFlow.functionalFlows",
                        },
                      ],
                      staticClass: "form-control",
                      attrs: {
                        id: "data-flow-functionalFlows",
                        "data-cy": "functionalFlows",
                        multiple: "",
                        name: "functionalFlows",
                      },
                      on: {
                        change: function ($event) {
                          var $$selectedVal = Array.prototype.filter
                            .call($event.target.options, function (o) {
                              return o.selected
                            })
                            .map(function (o) {
                              var val = "_value" in o ? o._value : o.value
                              return val
                            })
                          _vm.$set(
                            _vm.dataFlow,
                            "functionalFlows",
                            $event.target.multiple
                              ? $$selectedVal
                              : $$selectedVal[0]
                          )
                        },
                      },
                    },
                    _vm._l(
                      _vm.functionalFlows,
                      function (functionalFlowOption) {
                        return _c(
                          "option",
                          {
                            key: functionalFlowOption.id,
                            domProps: {
                              value: _vm.getSelected(
                                _vm.dataFlow.functionalFlows,
                                functionalFlowOption
                              ),
                            },
                          },
                          [
                            _vm._v(
                              "\n              " +
                                _vm._s(functionalFlowOption.alias) +
                                "\n            "
                            ),
                          ]
                        )
                      }
                    ),
                    0
                  )
                : _vm._e(),
            ]),
            _vm._v(" "),
            _c("div", { staticClass: "form-group" }, [
              _c(
                "label",
                {
                  staticClass: "form-control-label",
                  attrs: { for: "data-flow-flowInterface" },
                },
                [_vm._v("Flow Interface")]
              ),
              _vm._v(" "),
              _c(
                "select",
                {
                  directives: [
                    {
                      name: "model",
                      rawName: "v-model",
                      value: _vm.dataFlow.flowInterface,
                      expression: "dataFlow.flowInterface",
                    },
                  ],
                  staticClass: "form-control",
                  attrs: {
                    id: "data-flow-flowInterface",
                    "data-cy": "flowInterface",
                    name: "flowInterface",
                  },
                  on: {
                    change: function ($event) {
                      var $$selectedVal = Array.prototype.filter
                        .call($event.target.options, function (o) {
                          return o.selected
                        })
                        .map(function (o) {
                          var val = "_value" in o ? o._value : o.value
                          return val
                        })
                      _vm.$set(
                        _vm.dataFlow,
                        "flowInterface",
                        $event.target.multiple
                          ? $$selectedVal
                          : $$selectedVal[0]
                      )
                    },
                  },
                },
                [
                  _c("option", { domProps: { value: null } }),
                  _vm._v(" "),
                  _vm._l(_vm.flowInterfaces, function (flowInterfaceOption) {
                    return _c(
                      "option",
                      {
                        key: flowInterfaceOption.id,
                        domProps: {
                          value:
                            _vm.dataFlow.flowInterface &&
                            flowInterfaceOption.id ===
                              _vm.dataFlow.flowInterface.id
                              ? _vm.dataFlow.flowInterface
                              : flowInterfaceOption,
                        },
                      },
                      [
                        _vm._v(
                          "\n              " +
                            _vm._s(flowInterfaceOption.alias) +
                            "\n            "
                        ),
                      ]
                    )
                  }),
                ],
                2
              ),
            ]),
          ]),
          _vm._v(" "),
          _c("div", [
            _c(
              "button",
              {
                staticClass: "btn btn-secondary",
                attrs: {
                  type: "button",
                  id: "cancel-save",
                  "data-cy": "entityCreateCancelButton",
                },
                on: {
                  click: function ($event) {
                    return _vm.previousState()
                  },
                },
              },
              [
                _c("font-awesome-icon", { attrs: { icon: "ban" } }),
                _vm._v(" "),
                _c("span", [_vm._v("Cancel")]),
              ],
              1
            ),
            _vm._v(" "),
            _c(
              "button",
              {
                staticClass: "btn btn-primary",
                attrs: {
                  type: "submit",
                  id: "save-entity",
                  "data-cy": "entityCreateSaveButton",
                  disabled: _vm.$v.dataFlow.$invalid || _vm.isSaving,
                },
              },
              [
                _c("font-awesome-icon", { attrs: { icon: "save" } }),
                _vm._v(" "),
                _c("span", [_vm._v("Save")]),
              ],
              1
            ),
          ]),
        ]
      ),
    ]),
  ])
}
var staticRenderFns = []
render._withStripped = true



/***/ })

}]);
//# sourceMappingURL=src_main_webapp_app_entities_data-flow_data-flow-update_vue.js.map