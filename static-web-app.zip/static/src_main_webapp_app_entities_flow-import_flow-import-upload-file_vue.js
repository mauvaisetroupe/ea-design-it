(self["webpackChunkea_design_it"] = self["webpackChunkea_design_it"] || []).push([["src_main_webapp_app_entities_flow-import_flow-import-upload-file_vue"],{

/***/ "./node_modules/css-loader/dist/cjs.js??clonedRuleSet-3[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-3[0].rules[0].use[2]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./src/main/webapp/app/entities/flow-import/flow-import-upload-file.vue?vue&type=style&index=0&lang=css&":
/*!*******************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/css-loader/dist/cjs.js??clonedRuleSet-3[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-3[0].rules[0].use[2]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./src/main/webapp/app/entities/flow-import/flow-import-upload-file.vue?vue&type=style&index=0&lang=css& ***!
  \*******************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/***/ (function(module, __unused_webpack_exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_SOURCEMAP_IMPORT___ = __webpack_require__(/*! ../../../../../../node_modules/css-loader/dist/runtime/sourceMaps.js */ "./node_modules/css-loader/dist/runtime/sourceMaps.js");
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(/*! ../../../../../../node_modules/css-loader/dist/runtime/api.js */ "./node_modules/css-loader/dist/runtime/api.js");
var ___CSS_LOADER_EXPORT___ = ___CSS_LOADER_API_IMPORT___(___CSS_LOADER_API_SOURCEMAP_IMPORT___);
// Module
___CSS_LOADER_EXPORT___.push([module.id, "\n.rederror {\n  background-color: red;\n  color: white;\n}\n", "",{"version":3,"sources":["webpack://./src/main/webapp/app/entities/flow-import/flow-import-upload-file.vue"],"names":[],"mappings":";AA+GA;EACA,qBAAA;EACA,YAAA;AACA","sourcesContent":["<template>\n  <div>\n    <h2 id=\"page-heading\" data-cy=\"FlowImportHeading\">\n      <span id=\"flow-import-heading\">Flow Imports</span>\n      <div class=\"d-flex justify-content-end\" v-if=\"rowsLoaded || isFetching\">\n        <button class=\"btn btn-info mr-2\" v-on:click=\"filterErrors\" :disabled=\"isFetching\">\n          <font-awesome-icon icon=\"sync\" :spin=\"isFetching\"></font-awesome-icon> <span>Filter Errors</span>\n        </button>\n        <button class=\"btn btn-info mr-2\" v-on:click=\"exportErrors\" :disabled=\"isFetching\">\n          <font-awesome-icon icon=\"sync\" :spin=\"isFetching\"></font-awesome-icon> <span>Export Errors Report</span>\n        </button>\n      </div>\n    </h2>\n\n    <div v-if=\"!rowsLoaded\">\n      <div class=\"form-group\">\n        <div class=\"custom-file\">\n          <input type=\"file\" id=\"customFile\" @change=\"handleFileUpload($event)\" multiple />\n          <label class=\"custom-file-label\" for=\"customFile\">{{ excelFileNames }}</label>\n        </div>\n      </div>\n      <div class=\"form-group\" v-if=\"excelFiles\">\n        <button type=\"submit\" class=\"btn btn-primary mb-2\" v-on:click=\"submitFile()\">Submit File</button>\n      </div>\n    </div>\n\n    <br />\n    <div class=\"alert alert-warning\" v-if=\"!isFetching && dtos && dtos.length === 0\">\n      <span>No flowImports found</span>\n    </div>\n\n    <div v-for=\"dto in dtos\" :key=\"dto.excelFileName\">\n      <h4>{{ dto.excelFileName }}</h4>\n\n      <div class=\"table-responsive\" v-if=\"dto.flowImports && dto.flowImports.length > 0\">\n        <table class=\"table table-striped\" aria-describedby=\"dto.flowImports\">\n          <thead>\n            <tr>\n              <th scope=\"row\"><span>Import Interface Status</span></th>\n              <th scope=\"row\"><span>Import Functional Flow Status</span></th>\n              <th scope=\"row\"><span>Import Data Flow Status</span></th>\n              <th scope=\"row\"><span>Import Status Message</span></th>\n              <th scope=\"row\"><span>ID</span></th>\n              <th scope=\"row\"><span>Id Flow From Excel</span></th>\n              <th scope=\"row\"><span>Flow Alias</span></th>\n              <th scope=\"row\"><span>Source Element</span></th>\n              <th scope=\"row\"><span>Target Element</span></th>\n              <th scope=\"row\"><span>Description</span></th>\n              <th scope=\"row\"><span>Integration Pattern</span></th>\n              <th scope=\"row\"><span>Frequency</span></th>\n              <th scope=\"row\"><span>Format</span></th>\n              <th scope=\"row\"><span>Swagger</span></th>\n              <th scope=\"row\"><span>Blueprint</span></th>\n              <th scope=\"row\"><span>Blueprint Status</span></th>\n              <th scope=\"row\"><span>Flow Status</span></th>\n              <th scope=\"row\"><span>Comment</span></th>\n              <th scope=\"row\"><span>Document Name</span></th>\n              <th scope=\"row\"><span>Existing Application ID</span></th>\n              <th scope=\"row\"></th>\n            </tr>\n          </thead>\n          <tbody>\n            <tr v-for=\"flowImport in dto.flowImports\" :key=\"flowImport.id\" data-cy=\"entityTable\">\n              <td>\n                <span v-bind:class=\"[flowImport.importInterfaceStatus === 'ERROR' ? 'rederror' : '']\">\n                  {{ flowImport.importInterfaceStatus }}</span\n                >\n              </td>\n              <td>\n                <span v-bind:class=\"[flowImport.importFunctionalFlowStatus === 'ERROR' ? 'rederror' : '']\">{{\n                  flowImport.importFunctionalFlowStatus\n                }}</span>\n              </td>\n              <td>\n                <span v-bind:class=\"[flowImport.importDataFlowStatus === 'ERROR' ? 'rederror' : '']\">{{\n                  flowImport.importDataFlowStatus\n                }}</span>\n              </td>\n              <td>\n                <span v-bind:class=\"[flowImport.importStatusMessage === 'ERROR' ? 'rederror' : '']\">{{\n                  flowImport.importStatusMessage\n                }}</span>\n              </td>\n              <td>\n                <router-link :to=\"{ name: 'FlowImportView', params: { flowImportId: flowImport.id } }\">{{ flowImport.id }}</router-link>\n              </td>\n              <td>{{ flowImport.idFlowFromExcel }}</td>\n              <td>{{ flowImport.flowAlias }}</td>\n              <td>{{ flowImport.sourceElement }}</td>\n              <td>{{ flowImport.targetElement }}</td>\n              <td>{{ flowImport.description }}</td>\n              <td>{{ flowImport.integrationPattern }}</td>\n              <td>{{ flowImport.frequency }}</td>\n              <td>{{ flowImport.format }}</td>\n              <td>{{ flowImport.swagger }}</td>\n              <td>{{ flowImport.blueprint }}</td>\n              <td>{{ flowImport.blueprintStatus }}</td>\n              <td>{{ flowImport.flowStatus }}</td>\n              <td>{{ flowImport.comment }}</td>\n              <td>{{ flowImport.documentName }}</td>\n              <td>{{ flowImport.existingApplicationID }}</td>\n            </tr>\n          </tbody>\n        </table>\n      </div>\n    </div>\n  </div>\n</template>\n\n<script lang=\"ts\" src=\"./flow-import-upload-file.component.ts\"></script>\n<style>\n.rederror {\n  background-color: red;\n  color: white;\n}\n</style>\n"],"sourceRoot":""}]);
// Exports
module.exports = ___CSS_LOADER_EXPORT___;


/***/ }),

/***/ "./node_modules/ts-loader/index.js??clonedRuleSet-1[0].rules[0].use[0]!./src/main/webapp/app/entities/flow-import/flow-import-upload-file.component.ts?vue&type=script&lang=ts&":
/*!**************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/ts-loader/index.js??clonedRuleSet-1[0].rules[0].use[0]!./src/main/webapp/app/entities/flow-import/flow-import-upload-file.component.ts?vue&type=script&lang=ts& ***!
  \**************************************************************************************************************************************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var vue_property_decorator__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! vue-property-decorator */ "./node_modules/vue-property-decorator/lib/index.js");
/* harmony import */ var vue2_filters__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! vue2-filters */ "./node_modules/vue2-filters/dist/vue2-filters.js");
/* harmony import */ var vue2_filters__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(vue2_filters__WEBPACK_IMPORTED_MODULE_1__);
var __extends = (undefined && undefined.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        if (typeof b !== "function" && b !== null)
            throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __assign = (undefined && undefined.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __spreadArray = (undefined && undefined.__spreadArray) || function (to, from, pack) {
    if (pack || arguments.length === 2) for (var i = 0, l = from.length, ar; i < l; i++) {
        if (ar || !(i in from)) {
            if (!ar) ar = Array.prototype.slice.call(from, 0, i);
            ar[i] = from[i];
        }
    }
    return to.concat(ar || Array.prototype.slice.call(from));
};


var FlowImport = /** @class */ (function (_super) {
    __extends(FlowImport, _super);
    function FlowImport() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        //public flowImports: IFlowImport[] = [];
        _this.excelFiles = null;
        _this.isFetching = false;
        _this.fileSubmited = false;
        _this.rowsLoaded = false;
        _this.excelFileNames = 'Browse File';
        _this.dtos = null;
        _this.notFilteredDtos = null;
        return _this;
    }
    FlowImport.prototype.handleFileUpload = function (event) {
        console.log(event);
        this.excelFiles = Array.from(event.target.files);
        this.excelFileNames = this.excelFiles.map(function (f) { return f.name; }).join(', ');
    };
    FlowImport.prototype.submitFile = function () {
        this.notFilteredDtos = [];
        this.dtos = [];
        this.isFetching = true;
        this.fileSubmited = true;
        var excelFile = this.excelFiles.shift();
        this.uploadOneFile(excelFile);
    };
    FlowImport.prototype.uploadOneFile = function (excelFile) {
        var _this = this;
        this.flowImportService()
            .uploadFile([excelFile])
            .then(function (res) {
            var _a, _b;
            (_a = _this.dtos).push.apply(_a, res.data);
            (_b = _this.notFilteredDtos).push.apply(_b, res.data);
            _this.rowsLoaded = true;
            if (_this.excelFiles.length > 0) {
                _this.uploadOneFile(_this.excelFiles.shift());
            }
            else {
                _this.isFetching = false;
            }
        }, function (err) {
            _this.isFetching = false;
            _this.alertService().showHttpError(_this, err.response);
        });
    };
    FlowImport.prototype.filterErrors = function () {
        var _this = this;
        this.dtos = [];
        this.notFilteredDtos.forEach(function (dto) {
            var newdto = {};
            var newimport = [];
            dto.flowImports.forEach(function (elem) {
                var flowImport = elem;
                if (flowImport.importFunctionalFlowStatus === 'ERROR' ||
                    flowImport.importInterfaceStatus === 'ERROR' ||
                    flowImport.importDataFlowStatus === 'ERROR') {
                    newimport.push(flowImport);
                }
            });
            newdto = {
                excelFileName: dto.excelFileName,
                flowImports: newimport,
            };
            _this.dtos.push(newdto);
        });
    };
    FlowImport.prototype.getErrors = function () {
        var errors = [];
        this.notFilteredDtos.forEach(function (dto) {
            var line = 1;
            dto.flowImports.forEach(function (elem) {
                var flowImport = elem;
                if (flowImport.importFunctionalFlowStatus === 'ERROR' ||
                    flowImport.importInterfaceStatus === 'ERROR' ||
                    flowImport.importDataFlowStatus === 'ERROR') {
                    flowImport.id = dto.excelFileName + '_' + line.toString();
                    var errorRow = __assign({}, flowImport);
                    errors.push(errorRow);
                    console.log(errorRow);
                }
                line = line + 1;
            });
        });
        return errors;
    };
    FlowImport.prototype.exportErrors = function () {
        var errors = this.getErrors();
        var csvContent = 'data:text/csv;charset=utf-8,';
        csvContent += __spreadArray([Object.keys(errors[0]).join(';')], errors.map(function (row) { return Object.values(row).join(';').replace(/\n/gm, ''); }), true).join('\n')
            .replace(/(^\[)|(\]$)/gm, '');
        var data = encodeURI(csvContent);
        var link = document.createElement('a');
        link.setAttribute('href', data);
        link.setAttribute('download', 'export.csv');
        link.click();
    };
    __decorate([
        (0,vue_property_decorator__WEBPACK_IMPORTED_MODULE_0__.Inject)('flowImportService'),
        __metadata("design:type", Function)
    ], FlowImport.prototype, "flowImportService", void 0);
    __decorate([
        (0,vue_property_decorator__WEBPACK_IMPORTED_MODULE_0__.Inject)('alertService'),
        __metadata("design:type", Function)
    ], FlowImport.prototype, "alertService", void 0);
    FlowImport = __decorate([
        (0,vue_property_decorator__WEBPACK_IMPORTED_MODULE_0__.Component)({
            mixins: [(vue2_filters__WEBPACK_IMPORTED_MODULE_1___default().mixin)],
        })
    ], FlowImport);
    return FlowImport;
}(vue_property_decorator__WEBPACK_IMPORTED_MODULE_0__.Vue));
/* harmony default export */ __webpack_exports__["default"] = (FlowImport);


/***/ }),

/***/ "./src/main/webapp/app/entities/flow-import/flow-import-upload-file.vue":
/*!******************************************************************************!*\
  !*** ./src/main/webapp/app/entities/flow-import/flow-import-upload-file.vue ***!
  \******************************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _flow_import_upload_file_vue_vue_type_template_id_3d72c019___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./flow-import-upload-file.vue?vue&type=template&id=3d72c019& */ "./src/main/webapp/app/entities/flow-import/flow-import-upload-file.vue?vue&type=template&id=3d72c019&");
/* harmony import */ var _flow_import_upload_file_component_ts_vue_type_script_lang_ts___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./flow-import-upload-file.component.ts?vue&type=script&lang=ts& */ "./src/main/webapp/app/entities/flow-import/flow-import-upload-file.component.ts?vue&type=script&lang=ts&");
/* harmony import */ var _flow_import_upload_file_vue_vue_type_style_index_0_lang_css___WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./flow-import-upload-file.vue?vue&type=style&index=0&lang=css& */ "./src/main/webapp/app/entities/flow-import/flow-import-upload-file.vue?vue&type=style&index=0&lang=css&");
/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! !../../../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");



;


/* normalize component */

var component = (0,_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__["default"])(
  _flow_import_upload_file_component_ts_vue_type_script_lang_ts___WEBPACK_IMPORTED_MODULE_1__["default"],
  _flow_import_upload_file_vue_vue_type_template_id_3d72c019___WEBPACK_IMPORTED_MODULE_0__.render,
  _flow_import_upload_file_vue_vue_type_template_id_3d72c019___WEBPACK_IMPORTED_MODULE_0__.staticRenderFns,
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "src/main/webapp/app/entities/flow-import/flow-import-upload-file.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./src/main/webapp/app/entities/flow-import/flow-import-upload-file.component.ts?vue&type=script&lang=ts&":
/*!****************************************************************************************************************!*\
  !*** ./src/main/webapp/app/entities/flow-import/flow-import-upload-file.component.ts?vue&type=script&lang=ts& ***!
  \****************************************************************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_ts_loader_index_js_clonedRuleSet_1_0_rules_0_use_0_flow_import_upload_file_component_ts_vue_type_script_lang_ts___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../../node_modules/ts-loader/index.js??clonedRuleSet-1[0].rules[0].use[0]!./flow-import-upload-file.component.ts?vue&type=script&lang=ts& */ "./node_modules/ts-loader/index.js??clonedRuleSet-1[0].rules[0].use[0]!./src/main/webapp/app/entities/flow-import/flow-import-upload-file.component.ts?vue&type=script&lang=ts&");
 /* harmony default export */ __webpack_exports__["default"] = (_node_modules_ts_loader_index_js_clonedRuleSet_1_0_rules_0_use_0_flow_import_upload_file_component_ts_vue_type_script_lang_ts___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./src/main/webapp/app/entities/flow-import/flow-import-upload-file.vue?vue&type=template&id=3d72c019&":
/*!*************************************************************************************************************!*\
  !*** ./src/main/webapp/app/entities/flow-import/flow-import-upload-file.vue?vue&type=template&id=3d72c019& ***!
  \*************************************************************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": function() { return /* reexport safe */ _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_flow_import_upload_file_vue_vue_type_template_id_3d72c019___WEBPACK_IMPORTED_MODULE_0__.render; },
/* harmony export */   "staticRenderFns": function() { return /* reexport safe */ _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_flow_import_upload_file_vue_vue_type_template_id_3d72c019___WEBPACK_IMPORTED_MODULE_0__.staticRenderFns; }
/* harmony export */ });
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_flow_import_upload_file_vue_vue_type_template_id_3d72c019___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./flow-import-upload-file.vue?vue&type=template&id=3d72c019& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./src/main/webapp/app/entities/flow-import/flow-import-upload-file.vue?vue&type=template&id=3d72c019&");


/***/ }),

/***/ "./src/main/webapp/app/entities/flow-import/flow-import-upload-file.vue?vue&type=style&index=0&lang=css&":
/*!***************************************************************************************************************!*\
  !*** ./src/main/webapp/app/entities/flow-import/flow-import-upload-file.vue?vue&type=style&index=0&lang=css& ***!
  \***************************************************************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_style_loader_index_js_node_modules_css_loader_dist_cjs_js_clonedRuleSet_3_0_rules_0_use_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_clonedRuleSet_3_0_rules_0_use_2_node_modules_vue_loader_lib_index_js_vue_loader_options_flow_import_upload_file_vue_vue_type_style_index_0_lang_css___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../../node_modules/vue-style-loader/index.js!../../../../../../node_modules/css-loader/dist/cjs.js??clonedRuleSet-3[0].rules[0].use[1]!../../../../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../../../../node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-3[0].rules[0].use[2]!../../../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./flow-import-upload-file.vue?vue&type=style&index=0&lang=css& */ "./node_modules/vue-style-loader/index.js!./node_modules/css-loader/dist/cjs.js??clonedRuleSet-3[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-3[0].rules[0].use[2]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./src/main/webapp/app/entities/flow-import/flow-import-upload-file.vue?vue&type=style&index=0&lang=css&");
/* harmony import */ var _node_modules_vue_style_loader_index_js_node_modules_css_loader_dist_cjs_js_clonedRuleSet_3_0_rules_0_use_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_clonedRuleSet_3_0_rules_0_use_2_node_modules_vue_loader_lib_index_js_vue_loader_options_flow_import_upload_file_vue_vue_type_style_index_0_lang_css___WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_vue_style_loader_index_js_node_modules_css_loader_dist_cjs_js_clonedRuleSet_3_0_rules_0_use_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_clonedRuleSet_3_0_rules_0_use_2_node_modules_vue_loader_lib_index_js_vue_loader_options_flow_import_upload_file_vue_vue_type_style_index_0_lang_css___WEBPACK_IMPORTED_MODULE_0__);
/* harmony reexport (unknown) */ var __WEBPACK_REEXPORT_OBJECT__ = {};
/* harmony reexport (unknown) */ for(var __WEBPACK_IMPORT_KEY__ in _node_modules_vue_style_loader_index_js_node_modules_css_loader_dist_cjs_js_clonedRuleSet_3_0_rules_0_use_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_clonedRuleSet_3_0_rules_0_use_2_node_modules_vue_loader_lib_index_js_vue_loader_options_flow_import_upload_file_vue_vue_type_style_index_0_lang_css___WEBPACK_IMPORTED_MODULE_0__) if(__WEBPACK_IMPORT_KEY__ !== "default") __WEBPACK_REEXPORT_OBJECT__[__WEBPACK_IMPORT_KEY__] = function(key) { return _node_modules_vue_style_loader_index_js_node_modules_css_loader_dist_cjs_js_clonedRuleSet_3_0_rules_0_use_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_dist_cjs_js_clonedRuleSet_3_0_rules_0_use_2_node_modules_vue_loader_lib_index_js_vue_loader_options_flow_import_upload_file_vue_vue_type_style_index_0_lang_css___WEBPACK_IMPORTED_MODULE_0__[key]; }.bind(0, __WEBPACK_IMPORT_KEY__)
/* harmony reexport (unknown) */ __webpack_require__.d(__webpack_exports__, __WEBPACK_REEXPORT_OBJECT__);


/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./src/main/webapp/app/entities/flow-import/flow-import-upload-file.vue?vue&type=template&id=3d72c019&":
/*!****************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./src/main/webapp/app/entities/flow-import/flow-import-upload-file.vue?vue&type=template&id=3d72c019& ***!
  \****************************************************************************************************************************************************************************************************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": function() { return /* binding */ render; },
/* harmony export */   "staticRenderFns": function() { return /* binding */ staticRenderFns; }
/* harmony export */ });
var render = function () {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "div",
    [
      _c(
        "h2",
        { attrs: { id: "page-heading", "data-cy": "FlowImportHeading" } },
        [
          _c("span", { attrs: { id: "flow-import-heading" } }, [
            _vm._v("Flow Imports"),
          ]),
          _vm._v(" "),
          _vm.rowsLoaded || _vm.isFetching
            ? _c("div", { staticClass: "d-flex justify-content-end" }, [
                _c(
                  "button",
                  {
                    staticClass: "btn btn-info mr-2",
                    attrs: { disabled: _vm.isFetching },
                    on: { click: _vm.filterErrors },
                  },
                  [
                    _c("font-awesome-icon", {
                      attrs: { icon: "sync", spin: _vm.isFetching },
                    }),
                    _vm._v(" "),
                    _c("span", [_vm._v("Filter Errors")]),
                  ],
                  1
                ),
                _vm._v(" "),
                _c(
                  "button",
                  {
                    staticClass: "btn btn-info mr-2",
                    attrs: { disabled: _vm.isFetching },
                    on: { click: _vm.exportErrors },
                  },
                  [
                    _c("font-awesome-icon", {
                      attrs: { icon: "sync", spin: _vm.isFetching },
                    }),
                    _vm._v(" "),
                    _c("span", [_vm._v("Export Errors Report")]),
                  ],
                  1
                ),
              ])
            : _vm._e(),
        ]
      ),
      _vm._v(" "),
      !_vm.rowsLoaded
        ? _c("div", [
            _c("div", { staticClass: "form-group" }, [
              _c("div", { staticClass: "custom-file" }, [
                _c("input", {
                  attrs: { type: "file", id: "customFile", multiple: "" },
                  on: {
                    change: function ($event) {
                      return _vm.handleFileUpload($event)
                    },
                  },
                }),
                _vm._v(" "),
                _c(
                  "label",
                  {
                    staticClass: "custom-file-label",
                    attrs: { for: "customFile" },
                  },
                  [_vm._v(_vm._s(_vm.excelFileNames))]
                ),
              ]),
            ]),
            _vm._v(" "),
            _vm.excelFiles
              ? _c("div", { staticClass: "form-group" }, [
                  _c(
                    "button",
                    {
                      staticClass: "btn btn-primary mb-2",
                      attrs: { type: "submit" },
                      on: {
                        click: function ($event) {
                          return _vm.submitFile()
                        },
                      },
                    },
                    [_vm._v("Submit File")]
                  ),
                ])
              : _vm._e(),
          ])
        : _vm._e(),
      _vm._v(" "),
      _c("br"),
      _vm._v(" "),
      !_vm.isFetching && _vm.dtos && _vm.dtos.length === 0
        ? _c("div", { staticClass: "alert alert-warning" }, [
            _c("span", [_vm._v("No flowImports found")]),
          ])
        : _vm._e(),
      _vm._v(" "),
      _vm._l(_vm.dtos, function (dto) {
        return _c("div", { key: dto.excelFileName }, [
          _c("h4", [_vm._v(_vm._s(dto.excelFileName))]),
          _vm._v(" "),
          dto.flowImports && dto.flowImports.length > 0
            ? _c("div", { staticClass: "table-responsive" }, [
                _c(
                  "table",
                  {
                    staticClass: "table table-striped",
                    attrs: { "aria-describedby": "dto.flowImports" },
                  },
                  [
                    _vm._m(0, true),
                    _vm._v(" "),
                    _c(
                      "tbody",
                      _vm._l(dto.flowImports, function (flowImport) {
                        return _c(
                          "tr",
                          {
                            key: flowImport.id,
                            attrs: { "data-cy": "entityTable" },
                          },
                          [
                            _c("td", [
                              _c(
                                "span",
                                {
                                  class: [
                                    flowImport.importInterfaceStatus === "ERROR"
                                      ? "rederror"
                                      : "",
                                  ],
                                },
                                [
                                  _vm._v(
                                    "\n                " +
                                      _vm._s(flowImport.importInterfaceStatus)
                                  ),
                                ]
                              ),
                            ]),
                            _vm._v(" "),
                            _c("td", [
                              _c(
                                "span",
                                {
                                  class: [
                                    flowImport.importFunctionalFlowStatus ===
                                    "ERROR"
                                      ? "rederror"
                                      : "",
                                  ],
                                },
                                [
                                  _vm._v(
                                    _vm._s(
                                      flowImport.importFunctionalFlowStatus
                                    )
                                  ),
                                ]
                              ),
                            ]),
                            _vm._v(" "),
                            _c("td", [
                              _c(
                                "span",
                                {
                                  class: [
                                    flowImport.importDataFlowStatus === "ERROR"
                                      ? "rederror"
                                      : "",
                                  ],
                                },
                                [
                                  _vm._v(
                                    _vm._s(flowImport.importDataFlowStatus)
                                  ),
                                ]
                              ),
                            ]),
                            _vm._v(" "),
                            _c("td", [
                              _c(
                                "span",
                                {
                                  class: [
                                    flowImport.importStatusMessage === "ERROR"
                                      ? "rederror"
                                      : "",
                                  ],
                                },
                                [_vm._v(_vm._s(flowImport.importStatusMessage))]
                              ),
                            ]),
                            _vm._v(" "),
                            _c(
                              "td",
                              [
                                _c(
                                  "router-link",
                                  {
                                    attrs: {
                                      to: {
                                        name: "FlowImportView",
                                        params: { flowImportId: flowImport.id },
                                      },
                                    },
                                  },
                                  [_vm._v(_vm._s(flowImport.id))]
                                ),
                              ],
                              1
                            ),
                            _vm._v(" "),
                            _c("td", [
                              _vm._v(_vm._s(flowImport.idFlowFromExcel)),
                            ]),
                            _vm._v(" "),
                            _c("td", [_vm._v(_vm._s(flowImport.flowAlias))]),
                            _vm._v(" "),
                            _c("td", [
                              _vm._v(_vm._s(flowImport.sourceElement)),
                            ]),
                            _vm._v(" "),
                            _c("td", [
                              _vm._v(_vm._s(flowImport.targetElement)),
                            ]),
                            _vm._v(" "),
                            _c("td", [_vm._v(_vm._s(flowImport.description))]),
                            _vm._v(" "),
                            _c("td", [
                              _vm._v(_vm._s(flowImport.integrationPattern)),
                            ]),
                            _vm._v(" "),
                            _c("td", [_vm._v(_vm._s(flowImport.frequency))]),
                            _vm._v(" "),
                            _c("td", [_vm._v(_vm._s(flowImport.format))]),
                            _vm._v(" "),
                            _c("td", [_vm._v(_vm._s(flowImport.swagger))]),
                            _vm._v(" "),
                            _c("td", [_vm._v(_vm._s(flowImport.blueprint))]),
                            _vm._v(" "),
                            _c("td", [
                              _vm._v(_vm._s(flowImport.blueprintStatus)),
                            ]),
                            _vm._v(" "),
                            _c("td", [_vm._v(_vm._s(flowImport.flowStatus))]),
                            _vm._v(" "),
                            _c("td", [_vm._v(_vm._s(flowImport.comment))]),
                            _vm._v(" "),
                            _c("td", [_vm._v(_vm._s(flowImport.documentName))]),
                            _vm._v(" "),
                            _c("td", [
                              _vm._v(_vm._s(flowImport.existingApplicationID)),
                            ]),
                          ]
                        )
                      }),
                      0
                    ),
                  ]
                ),
              ])
            : _vm._e(),
        ])
      }),
    ],
    2
  )
}
var staticRenderFns = [
  function () {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("thead", [
      _c("tr", [
        _c("th", { attrs: { scope: "row" } }, [
          _c("span", [_vm._v("Import Interface Status")]),
        ]),
        _vm._v(" "),
        _c("th", { attrs: { scope: "row" } }, [
          _c("span", [_vm._v("Import Functional Flow Status")]),
        ]),
        _vm._v(" "),
        _c("th", { attrs: { scope: "row" } }, [
          _c("span", [_vm._v("Import Data Flow Status")]),
        ]),
        _vm._v(" "),
        _c("th", { attrs: { scope: "row" } }, [
          _c("span", [_vm._v("Import Status Message")]),
        ]),
        _vm._v(" "),
        _c("th", { attrs: { scope: "row" } }, [_c("span", [_vm._v("ID")])]),
        _vm._v(" "),
        _c("th", { attrs: { scope: "row" } }, [
          _c("span", [_vm._v("Id Flow From Excel")]),
        ]),
        _vm._v(" "),
        _c("th", { attrs: { scope: "row" } }, [
          _c("span", [_vm._v("Flow Alias")]),
        ]),
        _vm._v(" "),
        _c("th", { attrs: { scope: "row" } }, [
          _c("span", [_vm._v("Source Element")]),
        ]),
        _vm._v(" "),
        _c("th", { attrs: { scope: "row" } }, [
          _c("span", [_vm._v("Target Element")]),
        ]),
        _vm._v(" "),
        _c("th", { attrs: { scope: "row" } }, [
          _c("span", [_vm._v("Description")]),
        ]),
        _vm._v(" "),
        _c("th", { attrs: { scope: "row" } }, [
          _c("span", [_vm._v("Integration Pattern")]),
        ]),
        _vm._v(" "),
        _c("th", { attrs: { scope: "row" } }, [
          _c("span", [_vm._v("Frequency")]),
        ]),
        _vm._v(" "),
        _c("th", { attrs: { scope: "row" } }, [_c("span", [_vm._v("Format")])]),
        _vm._v(" "),
        _c("th", { attrs: { scope: "row" } }, [
          _c("span", [_vm._v("Swagger")]),
        ]),
        _vm._v(" "),
        _c("th", { attrs: { scope: "row" } }, [
          _c("span", [_vm._v("Blueprint")]),
        ]),
        _vm._v(" "),
        _c("th", { attrs: { scope: "row" } }, [
          _c("span", [_vm._v("Blueprint Status")]),
        ]),
        _vm._v(" "),
        _c("th", { attrs: { scope: "row" } }, [
          _c("span", [_vm._v("Flow Status")]),
        ]),
        _vm._v(" "),
        _c("th", { attrs: { scope: "row" } }, [
          _c("span", [_vm._v("Comment")]),
        ]),
        _vm._v(" "),
        _c("th", { attrs: { scope: "row" } }, [
          _c("span", [_vm._v("Document Name")]),
        ]),
        _vm._v(" "),
        _c("th", { attrs: { scope: "row" } }, [
          _c("span", [_vm._v("Existing Application ID")]),
        ]),
        _vm._v(" "),
        _c("th", { attrs: { scope: "row" } }),
      ]),
    ])
  },
]
render._withStripped = true



/***/ }),

/***/ "./node_modules/vue-style-loader/index.js!./node_modules/css-loader/dist/cjs.js??clonedRuleSet-3[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-3[0].rules[0].use[2]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./src/main/webapp/app/entities/flow-import/flow-import-upload-file.vue?vue&type=style&index=0&lang=css&":
/*!************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-style-loader/index.js!./node_modules/css-loader/dist/cjs.js??clonedRuleSet-3[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-3[0].rules[0].use[2]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./src/main/webapp/app/entities/flow-import/flow-import-upload-file.vue?vue&type=style&index=0&lang=css& ***!
  \************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/***/ (function(module, __unused_webpack_exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__(/*! !!../../../../../../node_modules/css-loader/dist/cjs.js??clonedRuleSet-3[0].rules[0].use[1]!../../../../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../../../../node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-3[0].rules[0].use[2]!../../../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./flow-import-upload-file.vue?vue&type=style&index=0&lang=css& */ "./node_modules/css-loader/dist/cjs.js??clonedRuleSet-3[0].rules[0].use[1]!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-3[0].rules[0].use[2]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./src/main/webapp/app/entities/flow-import/flow-import-upload-file.vue?vue&type=style&index=0&lang=css&");
if(content.__esModule) content = content.default;
if(typeof content === 'string') content = [[module.id, content, '']];
if(content.locals) module.exports = content.locals;
// add the styles to the DOM
var add = (__webpack_require__(/*! !../../../../../../node_modules/vue-style-loader/lib/addStylesClient.js */ "./node_modules/vue-style-loader/lib/addStylesClient.js")["default"])
var update = add("1dc5d5e6", content, false, {});
// Hot Module Replacement
if(false) {}

/***/ })

}]);
//# sourceMappingURL=src_main_webapp_app_entities_flow-import_flow-import-upload-file_vue.js.map